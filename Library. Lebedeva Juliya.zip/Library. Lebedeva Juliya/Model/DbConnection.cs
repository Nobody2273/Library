﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Lebedeva_Juliya.Model
{
    internal class DbConnection
    {
        //Класс отвечающий за взаимодействие с базой данных

        internal static string connectionStr = @"Server=localhost; Port=5432 ; DataBase=Library;
            User Id=postgres ; Password=123";
    }
}
