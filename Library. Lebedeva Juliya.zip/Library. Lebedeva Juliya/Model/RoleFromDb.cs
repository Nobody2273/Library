﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Lebedeva_Juliya.Classes;
using Npgsql;
using System.Windows;

namespace Library.Lebedeva_Juliya.Model
{
    internal class RoleFromDb
    {
        public string GetUserRole(int userId)
        {
            string roleName = null;
            try
            {
                using (NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connect.Open();

                    string sqlExp = @"SELECT r.role_name
                                    FROM user_library u
                                    JOIN role_user r ON u.role_id = r.role_id
                                    WHERE u.user_id = @userId";

                    using (NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect))
                    {
                        cmd.Parameters.AddWithValue("userId", userId);

                        object result = cmd.ExecuteScalar();
                        if (result != null)
                        {
                            roleName = result.ToString();
                        }
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show("Ошибка при получении роли пользователя: " + ex.Message);
            }

            return roleName;
        }
    }
}
