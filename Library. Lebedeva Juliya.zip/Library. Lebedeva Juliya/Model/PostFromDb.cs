﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Lebedeva_Juliya.Classes;
using Npgsql;
using System.Windows;

namespace Library.Lebedeva_Juliya.Model
{
    internal class PostFromDb
    {
        public List<Post> GetAllPosts()
        {
            List<Post> posts = new List<Post>();

            using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                try
                {
                    connection.Open();
                    string sql = "SELECT post_id, post, salary, duty FROM post ORDER BY post";

                    using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
                    {
                        using (NpgsqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                posts.Add(new Post
                                (
                                    postId: reader.GetInt32(0),
                                    post: reader.GetString(1),
                                    salary: reader.GetInt32(2),
                                    duty: reader.IsDBNull(3) ? null : reader.GetString(3)
                                ));
                            }
                        }
                    }
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show($"Ошибка загрузки должностей: {ex.Message}");
                }
            }

            return posts;
        }
    }
}
