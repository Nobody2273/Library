﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Lebedeva_Juliya.Classes;
using Npgsql;
using System.Windows;

namespace Library.Lebedeva_Juliya.Model
{
    internal class LanguageFromDb
    {
        public List<LanguageBook> LoadLanguages()
        {
            List<LanguageBook> languages = new List<LanguageBook>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);

            try
            {
                connection.Open();
                string sqlExp = "SELECT * from language_book;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        languages.Add(new LanguageBook(
                            languageId: reader.GetInt32(0),
                            languageCode: reader.GetString(1),
                            language_book: reader.GetString(2)
                        ));
                    }
                }
                reader.Close();
                return languages;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return languages;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
