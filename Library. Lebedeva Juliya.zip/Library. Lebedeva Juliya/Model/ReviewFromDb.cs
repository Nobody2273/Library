﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Library.Lebedeva_Juliya.Classes;
using Npgsql;

namespace Library.Lebedeva_Juliya.Model
{
    internal class ReviewFromDb
    {
        public int InsertReview(string reviewText, int estimation)
        {
            NpgsqlConnection connection = null;
            try
            {
                connection = new NpgsqlConnection(DbConnection.connectionStr);
                connection.Open();

                string sql = @"
                    INSERT INTO review (review_text, estimation, review_date)
                    VALUES (@reviewText, @estimation, @reviewDate)
                    RETURNING review_id;";

                using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@reviewText", reviewText);
                    command.Parameters.AddWithValue("@estimation", estimation);
                    command.Parameters.AddWithValue("@reviewDate", DateTime.Today);

                    object result = command.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : -1;
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show($"Ошибка при добавлении отзыва: {ex.Message}",
                    "Ошибка базы данных", MessageBoxButton.OK, MessageBoxImage.Error);
                return -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неожиданная ошибка: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return -1;
            }
            finally
            {
                if (connection != null && connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }


        public List<Review> LoadReviews()
        {
            List<Review> reviews = new List<Review>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);

            try
            {
                connection.Open();
                string sqlExp = @"SELECT 
                                    r.review_id,
                                    r.review_text,
                                    r.estimation,
                                    r.review_date,
                                    b.book_name,
                                    a.lastname_author || ' ' || a.firstname_author || 
                                        CASE WHEN a.patronymic_author IS NULL THEN '' ELSE ' ' || a.patronymic_author END as author_name,
                                    rd.lastname || ' ' || rd.firstname || 
                                        CASE WHEN rd.patronymic IS NULL THEN '' ELSE ' ' || rd.patronymic END as reader_name
                                FROM review r
                                JOIN card_of_reader cor ON r.review_id = cor.review_id
                                JOIN copy_book cb ON cor.copy_id = cb.copy_id
                                JOIN catalog_books b ON cb.catalog_id = b.catalog_id
                                JOIN author a ON b.author_id = a.author_id
                                JOIN reader rd ON cor.reader_id = rd.reader_id
                                ORDER BY r.review_date DESC";

                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        reviews.Add(new Review(
                            reviewId: reader.GetInt32(0),
                            reviewText: reader.GetString(1),
                            estimation: reader.GetInt32(2),
                            reviewDate: reader.GetDateTime(3),
                            bookName: reader.GetString(4),
                            authorName: reader.GetString(5),
                            readerName: reader.GetString(6)
                        ));
                    }
                }
                reader.Close();
                return reviews;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show($"Ошибка при загрузке отзывов: {ex.Message}");
                return reviews;
            }
            finally
            {
                connection.Close();
            }
        }
        public bool DeleteReview(int reviewId)
        {
            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connection.Open();

                    using (NpgsqlCommand command = new NpgsqlCommand(
                        "UPDATE card_of_reader SET review_id = NULL WHERE review_id = @reviewId",
                        connection))
                    {
                        command.Parameters.AddWithValue("reviewId", reviewId);
                        command.ExecuteNonQuery();
                    }

                    using (NpgsqlCommand command = new NpgsqlCommand(
                        "DELETE FROM review WHERE review_id = @reviewId",
                        connection))
                    {
                        command.Parameters.AddWithValue("reviewId", reviewId);
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении отзыва: {ex.Message}");
                return false;
            }
        }
    }
}
