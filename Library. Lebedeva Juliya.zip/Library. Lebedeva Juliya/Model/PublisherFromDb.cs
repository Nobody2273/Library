﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Lebedeva_Juliya.Classes;
using Npgsql;
using System.Windows;
using System.Security.Policy;
using System.Net;
using System.Numerics;

namespace Library.Lebedeva_Juliya.Model
{
    internal class PublisherFromDb
    {
        public List<PublisherBook> LoadPublishers()
        {
            List<PublisherBook> publishers = new List<PublisherBook>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);

            try
            {
                connection.Open();
                string sqlExp = "SELECT * from publisher;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        publishers.Add(new PublisherBook(
                            publisherId: reader.GetInt32(0),
                            publisherName: reader.GetString(1),
                            address: reader.GetString(2),
                            email: reader.GetString(2),
                            phone: reader.GetString(2),
                            website: reader.GetString(2),
                            contactPerson: reader.GetString(2)
                        ));
                    }
                }
                reader.Close();
                return publishers;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return publishers;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
