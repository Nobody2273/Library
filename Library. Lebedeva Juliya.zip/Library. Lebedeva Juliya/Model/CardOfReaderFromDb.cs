﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;

namespace Library.Lebedeva_Juliya.Model
{
    internal class CardOfReaderFromDb
    {
        CopyBookFromDb copyBookFromDb = new CopyBookFromDb();

        public bool IssueBook(int copyId, int readerId, int employeeId, int issueTypeId, int returnPeriod)
        {
            try
            {
                using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connection.Open();

                    var allCopyBooks = copyBookFromDb.LoadCopyBooks();

                    var copyBook = allCopyBooks.FirstOrDefault(cb => cb.CopyId == copyId && cb.Status == "В наличии");
                    if (copyBook == null)
                        return false;

                    var query = @"INSERT INTO card_of_reader (opening_date, return_period, return_date, 
                                        extension_book, copy_id, reader_id, penalty_id, review_id,
                                        employee_id, is_returned) 
                                VALUES (@opening_date, @return_period, @return_date, 
                                        @extension_book, @copy_id, @reader_id, 
                                        @penalty_id, @review_id, @employee_id, @is_returned);
                    
                                UPDATE copy_book SET availability_id = 2 WHERE copy_id = @copy_id;";

                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@opening_date", DateTime.Today);
                        command.Parameters.AddWithValue("@return_period", returnPeriod);
                        command.Parameters.AddWithValue("@return_date", DateTime.Today.AddDays(returnPeriod));
                        command.Parameters.AddWithValue("@extension_book", false);
                        command.Parameters.AddWithValue("@copy_id", copyId);
                        command.Parameters.AddWithValue("@reader_id", readerId);
                        command.Parameters.AddWithValue("@penalty_id", DBNull.Value);
                        command.Parameters.AddWithValue("@review_id", DBNull.Value);
                        command.Parameters.AddWithValue("@employee_id", employeeId);
                        command.Parameters.AddWithValue("@is_returned", false);

                        int rowsAffected = command.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при выдаче книги: {ex.Message}");
                return false;
            }
        }

        public int GetUnreturnedBooksCount(int readerId)
        {
            string sql = "SELECT get_unreturned_books_count(@readerId)";

            using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                connection.Open();
                using (var command = new NpgsqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@readerId", readerId);
                    var result = command.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : 0;
                }
            }
        }

        public bool HasUnreturnedCopies(int catalogId)
        {
            using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                connection.Open();
                string sql = @"SELECT COUNT(*) FROM card_of_reader cor
                      JOIN copy_book cb ON cor.copy_id = cb.copy_id
                      WHERE cb.catalog_id = @catalog_id AND cor.is_returned = false";

                using (var cmd = new NpgsqlCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("catalog_id", catalogId);
                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    return count > 0;
                }
            }
        }
    }
}
