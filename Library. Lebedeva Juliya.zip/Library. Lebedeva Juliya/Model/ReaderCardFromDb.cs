﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Lebedeva_Juliya.Classes;
using Npgsql;
using System.Windows;

namespace Library.Lebedeva_Juliya.Model
{
    internal class ReaderCardFromDb
    {
        public List<ReaderCard> LoadReaderCards()
        {
            List<ReaderCard> readerCards = new List<ReaderCard>();
            using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                try
                {
                    connection.Open();
                    string sqlExp = @"SELECT 
                                    card_of_reader_id, 
                                    opening_date, 
                                    return_period, 
                                    return_date, 
                                    extension_book, 
                                    copy_id, 
                                    reader_id, 
                                    penalty_id, 
                                    review_id, 
                                    is_returned 
                                    FROM card_of_reader";

                    using (NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection))
                    using (NpgsqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            readerCards.Add(new ReaderCard(
                                cardOfReader_id: reader.GetInt32(0),
                                opening_date: reader.GetDateTime(1),
                                return_period: reader.GetInt32(2),
                                return_date: reader.IsDBNull(3) ? DateTime.MinValue : reader.GetDateTime(3),
                                extension_book: reader.GetBoolean(4),
                                copy_id: reader.GetInt32(5),
                                reader_id: reader.GetInt32(6),
                                penaltyId: reader.IsDBNull(7) ? (int?)null : reader.GetInt32(7),
                                reviewId: reader.IsDBNull(8) ? (int?)null : reader.GetInt32(8),
                                is_returned: reader.GetBoolean(9)
                            ));
                        }
                    }
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show($"Ошибка при загрузке карточек: {ex.Message}");
                }
            }
            return readerCards;
        }

        // Продление книги
        public bool UpdateReaderCard(ReaderCard card)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                try
                {
                    connection.Open();

                    DateTime newReturnDate = card.Opening_date.AddDays(card.Return_period);

                    string sqlExp = @"UPDATE card_of_reader 
                            SET return_period = @return_period, 
                                return_date = @return_date,
                                extension_book = true 
                            WHERE card_of_reader_id = @card_id";

                    using (NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection))
                    {
                        command.Parameters.AddWithValue("@return_period", card.Return_period);
                        command.Parameters.AddWithValue("@return_date", newReturnDate);
                        command.Parameters.AddWithValue("@card_id", card.CardOfReader_id);

                        int rowsAffected = command.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show($"Ошибка при обновлении карточки: {ex.Message}");
                    return false;
                }
            }
        }

        // Возврат
        public bool ReturnBook(int cardId)
        {
            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connection.Open();

                    string sql = @"UPDATE card_of_reader 
                              SET is_returned = TRUE 
                              WHERE card_of_reader_id = @cardId";

                    using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@cardId", cardId);
                        int rowsAffected = command.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при возврате книги: {ex.Message}");
                return false;
            }
        }

        // Обновление карточки читателя с ссылкой на отзыв
        public bool UpdateCardWithReview(int cardId, int reviewId)
        {
            NpgsqlConnection connection = null;
            try
            {
                connection = new NpgsqlConnection(DbConnection.connectionStr);
                connection.Open();

                string sql = @"
                    UPDATE card_of_reader 
                    SET review_id = @reviewId
                    WHERE card_of_reader_id = @cardId;";

                using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@reviewId", reviewId);
                    command.Parameters.AddWithValue("@cardId", cardId);

                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show($"Ошибка при обновлении карточки: {ex.Message}",
                    "Ошибка базы данных", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неожиданная ошибка: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            finally
            {
                if (connection != null && connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
    }
}
