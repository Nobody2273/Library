﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Lebedeva_Juliya.Classes;
using Npgsql;
using System.Windows;

namespace Library.Lebedeva_Juliya.Model
{
    internal class ReaderFromDb
    {
        public List<Reader> LoadReaders()
        {
            List<Reader> readers = new List<Reader>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);

            try
            {
                connection.Open();
                string sqlExp = "SELECT * from reader;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string patronymic = reader.IsDBNull(4) ? null : reader.GetString(4);
                        DateTime? birthDate = reader.IsDBNull(5) ? (DateTime?)null : reader.GetDateTime(5);
                        string address = reader.IsDBNull(6) ? null : reader.GetString(6);

                        readers.Add(new Reader(
                            readerId: reader.GetInt32(0),
                            userId: reader.GetInt32(1),
                            firstname: reader.GetString(2),
                            lastname: reader.GetString(3),
                            patronymic: patronymic,
                            birthDate: birthDate,
                            address: address,
                            registrationDate: reader.GetDateTime(7)
                        ));
                    }
                }
                reader.Close();
                return readers;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return readers;
            }
            finally
            {
                connection.Close();
            }
        }

        public int GetReaderId(int userId)
        {
            try
            {
                using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connection.Open();

                    var cmd = new NpgsqlCommand(
                        "SELECT reader_id FROM reader WHERE user_id = @userId",
                        connection);
                    cmd.Parameters.AddWithValue("@userId", userId);

                    var result = cmd.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : -1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при получении ID читателя: {ex.Message}");
                return -1;
            }
        }
        public void RegistrationReader(int userId, string firstName, string lastName, string patronymic = null,
                              DateTime? birthDate = null, string address = null)
        {
            try
            {
                using (NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connect.Open();

                    string sql = @"
                INSERT INTO reader (
                    user_id, 
                    firstname, 
                    lastname, 
                    patronymic, 
                    birth_date, 
                    address, 
                    registration_date
                ) 
                VALUES (
                    @userId, 
                    @firstName, 
                    @lastName, 
                    @patronymic, 
                    @birthDate, 
                    @address, 
                    CURRENT_DATE
                )";

                    using (NpgsqlCommand command = new NpgsqlCommand(sql, connect))
                    {
                        command.Parameters.AddWithValue("@userId", userId);
                        command.Parameters.AddWithValue("@firstName", firstName);
                        command.Parameters.AddWithValue("@lastName", lastName);

                        command.Parameters.AddWithValue("@patronymic", (object)patronymic ?? DBNull.Value);
                        command.Parameters.AddWithValue("@birthDate", (object)birthDate ?? DBNull.Value);
                        command.Parameters.AddWithValue("@address", (object)address ?? DBNull.Value);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка регистрации читателя: {ex.Message}");
                throw;
            }
        }
    }
}
