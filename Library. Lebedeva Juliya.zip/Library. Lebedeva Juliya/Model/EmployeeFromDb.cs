﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.Windows;
using Library.Lebedeva_Juliya.Classes;
using System.Runtime.Remoting.Messaging;
using Npgsql.Internal;

namespace Library.Lebedeva_Juliya.Model
{
    internal class EmployeeFromDb
    {
        public Employee GetEmployeeByUserId(int userId)
        {
            using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                try
                {
                    connection.Open();

                    string sql = @"
                SELECT e.employee_id, e.firstname, e.lastname, e.patronymic, 
                               p.post, p.salary, e.hire_date
                        FROM employee e
                        JOIN post p ON e.post_id = p.post_id
                        JOIN user_library u ON e.user_id = u.user_id
                        WHERE u.user_id = @userId";

                    using (var command = new NpgsqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@userId", userId);

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new Employee(
                                    employeeId: reader.GetInt32(0),
                                    firstname: reader.GetString(1),
                                    lastname: reader.GetString(2),
                                    patronymic: reader.IsDBNull(3) ? null : reader.GetString(3),
                                    post: reader.GetString(4),
                                    salary: reader.GetDecimal(5),
                                    hireDate: reader.GetDateTime(6)
                                );
                            }
                        }
                    }
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show($"Ошибка при получении сотрудника: {ex.Message}");
                }
            }

            return null;
        }

        public List<Employee> LoadEmployees()
        {
            List<Employee> employees = new List<Employee>();

            using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                try
                {
                    connection.Open();
                    string sql = @"
                        SELECT e.employee_id, e.firstname, e.lastname, e.patronymic, 
                       p.post, p.salary, e.hire_date
                FROM employee e
                JOIN post p ON e.post_id = p.post_id";

                    using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
                    {
                        using (NpgsqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    employees.Add(new Employee
                                    (
                                        employeeId: reader.GetInt32(0),
                                        firstname: reader.GetString(1),
                                        lastname: reader.GetString(2),
                                        patronymic: reader.IsDBNull(3) ? null : reader.GetString(3),
                                        post: reader.GetString(4),
                                        salary: reader.GetDecimal(5),
                                        hireDate: reader.GetDateTime(6)
                                    ));
                                }
                            }
                        }
                    }
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show($"Ошибка загрузки сотрудников: {ex.Message}");
                }
            }

            return employees;
        }

        public int AddEmployee(string firstName, string lastName, string patronymic, int postId, int userId)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                try
                {
                    connection.Open();
                    string sql = @"
                        INSERT INTO employee (firstname, lastname, patronymic, post_id, user_id, hire_date)
                VALUES (@firstName, @lastName, @patronymic, @postId, @userId, CURRENT_DATE)
                RETURNING employee_id";

                    using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@firstName", firstName);
                        command.Parameters.AddWithValue("@lastName", lastName);
                        command.Parameters.AddWithValue("@patronymic", (object)patronymic ?? DBNull.Value);
                        command.Parameters.AddWithValue("@postId", postId);
                        command.Parameters.AddWithValue("@userId", userId);

                        return Convert.ToInt32(command.ExecuteScalar());
                    }
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show($"Ошибка добавления сотрудника: {ex.Message}");
                    return -1;
                }
            }
        }

        public int GetUserIdByEmployeeId(int employeeId)
        {
            try
            {
                using (NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connect.Open();
                    string sql = "SELECT user_id FROM employee WHERE employee_id = @employeeId";
                    NpgsqlCommand cmd = new NpgsqlCommand(sql, connect);
                    cmd.Parameters.AddWithValue("@employeeId", employeeId);

                    object result = cmd.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при получении userId: {ex.Message}");
                return 0;
            }
        }
    }
}
