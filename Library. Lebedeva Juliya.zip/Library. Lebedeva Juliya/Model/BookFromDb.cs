﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.Windows;
using Library.Lebedeva_Juliya.Classes;
using System.IO;

namespace Library.Lebedeva_Juliya.Model
{
    internal class BookFromDb
    {
        public List<Book> LoadBook()
        {
            List<Book> books = new List<Book>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);

            try
            {
                connection.Open();
                string sqlExp = "SELECT catalog_id, book_name, number_of_copies, number_of_pages, " +
                                "price, date_of_publication, content_book, " +
                                "catalog_books.image, language_book, publisher_name, " +
                                "age_limit, firstname_author, lastname_author, " +
                                "patronymic_author, category " +
                                "FROM public.catalog_books " +
                                "join language_book on language_book.language_id = catalog_books.language_id " +
                                "join publisher on publisher.publisher_id = catalog_books.publisher_id " +
                                "join age_limit on age_limit.age_limit_id = catalog_books.age_limit_id " +
                                "join author on author.author_id = catalog_books.author_id " +
                                "join genre on genre.genre_id = catalog_books.genre_id " +
                                "order by catalog_id;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        books.Add(new Book(
                            catalogId: reader.GetInt32(0),
                            bookName: reader.GetString(1),
                            numberOfCopies: reader.GetInt32(2),
                            numberOfPages: reader.GetInt32(3),
                            price: reader.GetInt32(4),
                            dateOfPublication: reader.GetDateTime(5),
                            contentBook: reader.IsDBNull(6) ? string.Empty : reader.GetString(6),
                            language: reader.GetString(8),
                            publisher: reader.GetString(9),
                            ageLimit: reader.GetInt32(10),
                            firstnameAuthor: reader.IsDBNull(11) ? string.Empty : reader.GetString(11),
                            lastnameAuthor: reader.GetString(12),
                            patronymicAuthor: reader.IsDBNull(13) ? string.Empty : reader.GetString(13),
                            genre: reader.GetString(14),
                            image: reader.IsDBNull(7) ? string.Empty : reader.GetString(7)
                        ));
                    }
                }
                reader.Close();
                return books;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return books;
            }
            finally
            {
                connection.Close();
            }
        }

        // Получение списка книг, добавленных на полку читателя по читателю
        public List<Book> LoadBookByReader(int readerId)
        {
            List<Book> books = new List<Book>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);

            try
            {
                connection.Open();
                string sqlExp = "SELECT catalog_books.catalog_id, book_name, number_of_copies, number_of_pages, " +
                                "price, date_of_publication, content_book, " +
                                "catalog_books.image, language_book, publisher_name, " +
                                "age_limit, firstname_author, lastname_author, " +
                                "patronymic_author, category " +
                                "FROM public.catalog_books " +
                                "join language_book on language_book.language_id = catalog_books.language_id " +
                                "join publisher on publisher.publisher_id = catalog_books.publisher_id " +
                                "join age_limit on age_limit.age_limit_id = catalog_books.age_limit_id " +
                                "join author on author.author_id = catalog_books.author_id " +
                                "join genre on genre.genre_id = catalog_books.genre_id " +
                                "join reader_shelf on reader_shelf.catalog_id = catalog_books.catalog_id " +
                                "where reader_shelf.reader_id = @readerId " +
                                "order by catalog_books.catalog_id;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                command.Parameters.AddWithValue("@readerId", readerId);
                NpgsqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        books.Add(new Book(
                            catalogId: reader.GetInt32(0),
                            bookName: reader.GetString(1),
                            numberOfCopies: reader.GetInt32(2),
                            numberOfPages: reader.GetInt32(3),
                            price: reader.GetInt32(4),
                            dateOfPublication: reader.GetDateTime(5),
                            contentBook: reader.IsDBNull(6) ? string.Empty : reader.GetString(6),
                            language: reader.GetString(8),
                            publisher: reader.GetString(9),
                            ageLimit: reader.GetInt32(10),
                            firstnameAuthor: reader.IsDBNull(11) ? string.Empty : reader.GetString(11),
                            lastnameAuthor: reader.GetString(12),
                            patronymicAuthor: reader.IsDBNull(13) ? string.Empty : reader.GetString(13),
                            genre: reader.GetString(14),
                            image: reader.IsDBNull(7) ? string.Empty : reader.GetString(7)
                        ));
                    }
                }
                reader.Close();
                return books;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return books;
            }
            finally
            {
                connection.Close();
            }
        }

        public int AddBook(Book book)
        {
            using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                connection.Open();

                int authorId = GetOrCreateAuthor(
                    connection,
                    book.Firstname_author,
                    book.Lastname_author,
                    book.Patronymic_author);

                using (var cmd = new NpgsqlCommand(@"
                            INSERT INTO catalog_books (book_name, number_of_copies, number_of_pages, 
                                price, date_of_publication, content_book, image,
                                language_id, publisher_id, age_limit_id, author_id, genre_id) 
                            VALUES (@book_name, @number_of_copies, @number_of_pages, 
                                @price, @date_of_publication, @content_book, 
                                @image,
                                (SELECT language_id FROM language_book WHERE language_book = @language),
                                (SELECT publisher_id FROM publisher WHERE publisher_name = @publisher),
                                (SELECT age_limit_id FROM age_limit WHERE age_limit = @age_limit),
                                @author_id,
                                (SELECT genre_id FROM genre WHERE category = @genre))
                            RETURNING catalog_id;", connection))
                {
                    cmd.Parameters.AddWithValue("book_name", book.Book_name);
                    cmd.Parameters.AddWithValue("number_of_copies", book.Number_of_copies);
                    cmd.Parameters.AddWithValue("number_of_pages", book.Number_of_pages);
                    cmd.Parameters.AddWithValue("price", book.Price);
                    cmd.Parameters.AddWithValue("date_of_publication", book.Date_of_publication);
                    cmd.Parameters.AddWithValue("content_book", book.Content_book ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("image", book.ImageWithPath ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("language", book.Language);
                    cmd.Parameters.AddWithValue("publisher", book.Publisher);
                    cmd.Parameters.AddWithValue("age_limit", book.Age_limit);
                    cmd.Parameters.AddWithValue("author_id", authorId);
                    cmd.Parameters.AddWithValue("genre", book.Genre);

                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        private int GetOrCreateAuthor(NpgsqlConnection connection, string firstName, string lastName, string patronymic)
        {
            using (var cmd = new NpgsqlCommand("SELECT author_id FROM author WHERE firstname_author = @firstname AND lastname_author = @lastname AND patronymic_author = @patronymic", connection))
            {
                cmd.Parameters.AddWithValue("firstname", firstName);
                cmd.Parameters.AddWithValue("lastname", lastName);
                cmd.Parameters.AddWithValue("patronymic", patronymic ?? (object)DBNull.Value);

                var result = cmd.ExecuteScalar();
                if (result != null)
                {
                    return Convert.ToInt32(result);
                }
            }

            using (var cmd = new NpgsqlCommand(@"
                INSERT INTO author (firstname_author, lastname_author, 
                    patronymic_author, date_of_birth, country_id) 
                VALUES (@firstname, @lastname, @patronymic,
                    @date_of_birth,
                    (SELECT country_id FROM country WHERE country_name = 'Россия'))
                RETURNING author_id;", connection))
            {
                cmd.Parameters.AddWithValue("firstname", firstName);
                cmd.Parameters.AddWithValue("lastname", lastName);
                cmd.Parameters.AddWithValue("patronymic", patronymic ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("date_of_birth", new DateTime(1900, 1, 1)); // дата по умолчанию

                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public bool DeleteBook(int catalogId)
        {
            using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                connection.Open();

                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        using (var cmd = new NpgsqlCommand("DELETE FROM reader_shelf WHERE catalog_id = @catalog_id", connection))
                        {
                            cmd.Parameters.AddWithValue("catalog_id", catalogId);
                            cmd.ExecuteNonQuery();
                        }

                        using (var cmd = new NpgsqlCommand("DELETE FROM copy_book WHERE catalog_id = @catalog_id", connection))
                        {
                            cmd.Parameters.AddWithValue("catalog_id", catalogId);
                            cmd.ExecuteNonQuery();
                        }

                        using (var cmd = new NpgsqlCommand("DELETE FROM catalog_books WHERE catalog_id = @catalog_id", connection))
                        {
                            cmd.Parameters.AddWithValue("catalog_id", catalogId);
                            int rowsAffected = cmd.ExecuteNonQuery();

                            transaction.Commit();
                            return rowsAffected > 0;
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show($"Ошибка при удалении книги: {ex.Message}");
                        return false;
                    }
                }
            }
        }

        public bool UpdateBook(int catalogId, Book book)
        {
            using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                connection.Open();

                using (var authorCmd = new NpgsqlCommand(@"
                            UPDATE author 
                            SET 
                                lastname_author = @lastname_author,
                                firstname_author = @firstname_author,
                                patronymic_author = @patronymic_author
                            WHERE author_id = (
                                SELECT author_id FROM catalog_books WHERE catalog_id = @catalog_id)", connection))
                {
                    authorCmd.Parameters.AddWithValue("catalog_id", catalogId);
                    authorCmd.Parameters.AddWithValue("lastname_author", book.Lastname_author);
                    authorCmd.Parameters.AddWithValue("firstname_author", book.Firstname_author);
                    authorCmd.Parameters.AddWithValue("patronymic_author", book.Patronymic_author ?? (object)DBNull.Value);
                    authorCmd.ExecuteNonQuery();
                }

                using (var cmd = new NpgsqlCommand(@"
                            UPDATE catalog_books 
                            SET 
                                book_name = @book_name,
                                genre_id = (SELECT genre_id FROM genre WHERE category = @genre),
                                publisher_id = (SELECT publisher_id FROM publisher WHERE publisher_name = @publisher),
                                language_id = (SELECT language_id FROM language_book WHERE language_book = @language),
                                age_limit_id = (SELECT age_limit_id FROM age_limit WHERE age_limit = @age_limit),
                                date_of_publication = @date_of_publication,
                                number_of_pages = @number_of_pages,
                                price = @price,
                                content_book = @content_book,
                                image = @image
                            WHERE catalog_id = @catalog_id", connection))
                {
                    cmd.Parameters.AddWithValue("catalog_id", catalogId);
                    cmd.Parameters.AddWithValue("book_name", book.Book_name);
                    cmd.Parameters.AddWithValue("genre", book.Genre);
                    cmd.Parameters.AddWithValue("publisher", book.Publisher);
                    cmd.Parameters.AddWithValue("language", book.Language);
                    cmd.Parameters.AddWithValue("age_limit", book.Age_limit);
                    cmd.Parameters.AddWithValue("date_of_publication", book.Date_of_publication);
                    cmd.Parameters.AddWithValue("number_of_pages", book.Number_of_pages);
                    cmd.Parameters.AddWithValue("price", book.Price);
                    cmd.Parameters.AddWithValue("image", book.ImageWithPath ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("content_book", book.Content_book ?? (object)DBNull.Value);

                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
        }
    }
}
