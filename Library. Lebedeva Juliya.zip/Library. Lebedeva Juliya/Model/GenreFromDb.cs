﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Lebedeva_Juliya.Classes;
using Npgsql;
using System.Windows;

namespace Library.Lebedeva_Juliya.Model
{
    internal class GenreFromDb
    {
        public List<Genre> LoadGenres()
        {
            List<Genre> genres = new List<Genre>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);

            try
            {
                connection.Open();
                string sqlExp = "SELECT * from genre;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        genres.Add(new Genre(
                            genreId: reader.GetInt32(0),
                            category: reader.GetString(1),
                            contentGenre: reader.GetString(2)
                        ));
                    }
                }
                reader.Close();
                return genres;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return genres;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
