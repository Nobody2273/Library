﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.Windows;
using Library.Lebedeva_Juliya.Classes;

namespace Library.Lebedeva_Juliya.Model
{
    // Класс, связанный с таблицей User
    internal class UserFromDb
    {
        //Метод получения пользователя по логину и паролю
        public User GetUser(string login, string password)
        {
            User user = null;
            try
            {
                using (NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connect.Open();
                    string sqlExp = "Select * from user_library where login = @login";
                    NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                    cmd.Parameters.AddWithValue("login", login);
                    NpgsqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read();
                        if (password != "")
                        {
                            if (Verification.VerifySHA512Hash(password, (string)reader["password_user"]))
                            {
                                user = new User(
                                        userId: reader.GetInt32(0),
                                        login: reader.GetString(1),
                                        passwordUser: reader.GetString(2),
                                        email: reader.GetString(3),
                                        phone: reader.GetString(4),
                                        roleId: reader.GetInt32(5),
                                        isActive: reader.GetBoolean(6)
                                );
                            }
                            else
                            {
                                MessageBox.Show("Неверный пароль");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Нет такого пользователя");
                    }
                    return user;
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return user;
            }
        }

        //Метод проверки пароля по паролю и повторному вводу пароля
        public bool CheckPassword(string password, string passRepeat)
        {
            if (password.Length < 6)
            {
                MessageBox.Show("Длина пароля не может быть меньше 6 символов");
                return false;
            }
            else
            {
                bool f, f1, f2;
                f = f1 = f2 = false;
                for (int i = 0; i < password.Length; i++)
                {
                    if (Char.IsDigit(password[i])) f1 = true;
                    if (Char.IsUpper(password[i])) f2 = true;
                    if (f1 && f2) break;
                }
                if (!(f1 && f2))
                {
                    MessageBox.Show("Пароль должен содержать хотя бы одну цифру и одну заглавную букву!");
                    return f1 && f2;
                }
                else
                {
                    string symbol = "!@#$%^&*";
                    for (int i = 0; i < password.Length; i++)
                    {
                        for (int j = 0; j < symbol.Length; j++)
                        {
                            if (password[i] == symbol[j])
                            {
                                f = true;
                                break;
                            }
                        }
                    }
                    if (!f)
                        MessageBox.Show("Пароль должен содержать один из символов (!@#$%^&*)");
                    if ((password == passRepeat) && f)
                        return true;
                    else
                    {
                        MessageBox.Show("Неверно подтвержден пароль!");
                        return false;
                    }
                }
            }
        }

        // Метод проверки пользователя по логину
        public bool CheckUser(string login)
        {
            try
            {
                using (NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connect.Open();
                    string sqlExp = "SELECT COUNT(1) FROM user_library WHERE login = @login";
                    NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                    cmd.Parameters.AddWithValue("@login", login);
                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    return count > 0;
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show($"Ошибка при проверке пользователя: {ex.Message}");
                return true;
            }
        }

        // Метод добавления пользователя в базу данных
        public int UserAdd(string login, string password, string email, string phone, int roleId)
        {
            try
            {
                using (NpgsqlConnection connect = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connect.Open();

                    string hashedPassword = Verification.GetSHA512Hash(password);

                    string sqlUser = @"
                INSERT INTO user_library (login, password_user, email, phone, role_id) 
                VALUES (@login, @password, @email, @phone, @roleId)
                RETURNING user_id;";

                    using (NpgsqlCommand command = new NpgsqlCommand(sqlUser, connect))
                    {
                        command.Parameters.AddWithValue("@login", login);
                        command.Parameters.AddWithValue("@password", hashedPassword);
                        command.Parameters.AddWithValue("@email", email);
                        command.Parameters.AddWithValue("@phone", phone);
                        command.Parameters.AddWithValue("@roleId", roleId);

                        return (int)command.ExecuteScalar();
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show($"Ошибка добавления пользователя: {ex.Message}");
                return -1;
            }
        }

        // Профиль пользователя
        public UserProfil GetUserProfile(int userId)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                connection.Open();

                using (NpgsqlCommand command = new NpgsqlCommand("SELECT * FROM get_user_profile(@userId)", connection))
                {
                    command.Parameters.AddWithValue("userId", userId);

                    using (NpgsqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new UserProfil
                            {
                                UserId = reader.GetInt32(0),
                                Login = reader.GetString(1),
                                Email = reader.IsDBNull(2) ? null : reader.GetString(2),
                                Phone = reader.IsDBNull(3) ? null : reader.GetString(3),
                                RoleName = reader.GetString(4),
                                DocumentSeries = reader.IsDBNull(5) ? null : reader.GetString(5),
                                DocumentNumber = reader.IsDBNull(6) ? null : reader.GetString(6),
                                DocumentIssueDate = reader.IsDBNull(7) ? (DateTime?)null : reader.GetDateTime(7),
                                DocumentIssuedBy = reader.IsDBNull(8) ? null : reader.GetString(8),

                                // Общие поля (могут быть у читателя или сотрудника)
                                FirstName = reader.IsDBNull(9) ? null : reader.GetString(9),
                                LastName = reader.IsDBNull(10) ? null : reader.GetString(10),
                                Patronymic = reader.IsDBNull(11) ? null : reader.GetString(11),

                                // Только для читателя
                                BirthDate = reader.IsDBNull(12) ? (DateTime?)null : reader.GetDateTime(12),
                                Address = reader.IsDBNull(13) ? null : reader.GetString(13),
                                RegistrationDate = reader.IsDBNull(14) ? (DateTime?)null : reader.GetDateTime(14),

                                // Только для сотрудника
                                Position = reader.IsDBNull(15) ? null : reader.GetString(15)
                            };
                        }
                    }
                }
            }

            return null;
        }

        
        private bool ValidatePhoneNumber(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone)) return true;

            return phone.All(char.IsDigit) && phone.Length >= 10 && phone.Length <= 15;
        }

        private bool ValidateDate(DateTime? date)
        {
            if (!date.HasValue) return true;

            return date.Value <= DateTime.Today && date.Value.Year >= 1900;
        }

        public bool UpdateUserProfile(UserProfil profile)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(profile.Phone) && !ValidatePhoneNumber(profile.Phone))
                {
                    MessageBox.Show("Номер телефона должен содержать только цифры и быть длиной 11 символов",
                                  "Ошибка валидации", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                if (profile.DocumentIssueDate.HasValue && !ValidateDate(profile.BirthDate))
                {
                    MessageBox.Show("Дата рождения должна быть действительной",
                                  "Ошибка валидации", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                if (profile.DocumentIssueDate.HasValue && !ValidateDate(profile.DocumentIssueDate))
                {
                    MessageBox.Show("Дата выдачи документа должна быть действительной",
                                  "Ошибка валидации", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connection.Open();

                    int? postId = null;
                    if (profile.IsEmployee && !string.IsNullOrWhiteSpace(profile.Position))
                    {
                        using (NpgsqlCommand getPostCmd = new NpgsqlCommand(
                            "SELECT post_id FROM post WHERE post = @position", connection))
                        {
                            getPostCmd.Parameters.AddWithValue("position", profile.Position);
                            var result = getPostCmd.ExecuteScalar();
                            if (result != null)
                            {
                                postId = Convert.ToInt32(result);
                            }
                        }
                    }

                    using (NpgsqlCommand command = new NpgsqlCommand(
                        "SELECT update_user_profile(@userId, @email, @phone, @docSeries, @docNumber, @docIssueDate, @docIssuedBy, " +
                        "@lastName, @firstName, @patronymic, @birthDate, @address, @postId)",
                        connection))
                    {
                        command.Parameters.AddWithValue("userId", profile.UserId);
                        command.Parameters.AddWithValue("email", (object)profile.Email ?? DBNull.Value);
                        command.Parameters.AddWithValue("phone", (object)profile.Phone ?? DBNull.Value);
                        command.Parameters.AddWithValue("docSeries", (object)profile.DocumentSeries ?? DBNull.Value);
                        command.Parameters.AddWithValue("docNumber", (object)profile.DocumentNumber ?? DBNull.Value);

                        var docIssueDateParam = new NpgsqlParameter("docIssueDate", NpgsqlTypes.NpgsqlDbType.Date);
                        docIssueDateParam.Value = (object)profile.DocumentIssueDate ?? DBNull.Value;
                        command.Parameters.Add(docIssueDateParam);

                        command.Parameters.AddWithValue("docIssuedBy", (object)profile.DocumentIssuedBy ?? DBNull.Value);
                        command.Parameters.AddWithValue("lastName", (object)profile.LastName ?? DBNull.Value);
                        command.Parameters.AddWithValue("firstName", (object)profile.FirstName ?? DBNull.Value);
                        command.Parameters.AddWithValue("patronymic", (object)profile.Patronymic ?? DBNull.Value);

                        var birthDateParam = new NpgsqlParameter("birthDate", NpgsqlTypes.NpgsqlDbType.Date);
                        birthDateParam.Value = (object)profile.BirthDate ?? DBNull.Value;
                        command.Parameters.Add(birthDateParam);

                        command.Parameters.AddWithValue("address", (object)profile.Address ?? DBNull.Value);

                        command.Parameters.AddWithValue("postId", (object)postId ?? DBNull.Value);

                        command.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении профиля: {ex.Message}",
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        public bool DeleteEmployee(int userId)
        {
            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connection.Open();

                    using (var transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            using (NpgsqlCommand command = new NpgsqlCommand(
                                "DELETE FROM card_of_reader WHERE reader_id IN " +
                                "(SELECT reader_id FROM reader WHERE user_id = @userId)",
                                connection, transaction))
                            {
                                command.Parameters.AddWithValue("userId", userId);
                                command.ExecuteNonQuery();
                            }

                            using (NpgsqlCommand command = new NpgsqlCommand(
                                "DELETE FROM reader_shelf WHERE reader_id IN " +
                                "(SELECT reader_id FROM reader WHERE user_id = @userId)",
                                connection, transaction))
                            {
                                command.Parameters.AddWithValue("userId", userId);
                                command.ExecuteNonQuery();
                            }

                            using (NpgsqlCommand command = new NpgsqlCommand(
                                "DELETE FROM reader WHERE user_id = @userId",
                                connection, transaction))
                            {
                                command.Parameters.AddWithValue("userId", userId);
                                command.ExecuteNonQuery();
                            }

                            using (NpgsqlCommand command = new NpgsqlCommand(
                                "DELETE FROM employee WHERE user_id = @userId",
                                connection, transaction))
                            {
                                command.Parameters.AddWithValue("userId", userId);
                                command.ExecuteNonQuery();
                            }

                            using (NpgsqlCommand command = new NpgsqlCommand(
                                "DELETE FROM personal_data WHERE user_id = @userId",
                                connection, transaction))
                            {
                                command.Parameters.AddWithValue("userId", userId);
                                command.ExecuteNonQuery();
                            }

                            using (NpgsqlCommand command = new NpgsqlCommand(
                                "DELETE FROM user_library WHERE user_id = @userId",
                                connection, transaction))
                            {
                                command.Parameters.AddWithValue("userId", userId);
                                int rowsAffected = command.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    transaction.Commit();
                                    return true;
                                }
                            }
                        }
                        catch
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении сотрудника: {ex.Message}");
                return false;
            }
            return false;
        }

        public bool IsEmailValid(string email)
        {
            using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                connection.Open();

                using (var cmd = new NpgsqlCommand("SELECT is_valid_email(@email)", connection))
                {
                    cmd.Parameters.AddWithValue("email", email ?? string.Empty);
                    var result = cmd.ExecuteScalar();
                    return result != null && (bool)result;
                }
            }
        }

        public bool IsEmailUnique(string email)
        {
            using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                connection.Open();

                using (var cmd = new NpgsqlCommand(
                    "SELECT COUNT(*) FROM user_library WHERE email = @email", connection))
                {
                    cmd.Parameters.AddWithValue("email", email ?? string.Empty);
                    return (long)cmd.ExecuteScalar() == 0;
                }
            }
        }
    }
}
