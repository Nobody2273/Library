﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Lebedeva_Juliya.Classes;
using Npgsql;
using System.Windows;
using System.Runtime.Remoting.Contexts;
using System.Security.Policy;
using System.Windows.Documents;

namespace Library.Lebedeva_Juliya.Model
{
    internal class CopyBookFromDb
    {
        public List<CopyBook> LoadCopyBooks()
        {
            List<CopyBook> copies = new List<CopyBook>();
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);

            try
            {
                connection.Open();
                string sqlExp = "SELECT copy_id, delivery_date, \"condition\", " +
                                "catalog_books.book_name, availability.status " +
                                "FROM copy_book " +
                                "join catalog_books on catalog_books.catalog_id = copy_book.catalog_id " +
                                "join availability on availability.availability_id = copy_book.availability_id " +
                                "order by copy_id;";
                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                NpgsqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        copies.Add(new CopyBook(
                             copyId: reader.GetInt32(0),
                             deliveryDate: reader.GetDateTime(1),
                             condition: reader.GetString(2),
                             bookName: reader.GetString(3),
                             status: reader.GetString(4)
                         ));
                    }
                }
                reader.Close();
                return copies;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return copies;
            }
            finally
            {
                connection.Close();
            }
        }

        public int CountAvailableCopies(int catalogId)
        {
            int availableCount = 0;
            using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                try
                {
                    connection.Open();
                    string sqlExp = @"SELECT COUNT(*) FROM copy_book " +
                                    "JOIN availability ON availability.availability_id = copy_book.availability_id " +
                                    "WHERE copy_book.catalog_id = @catalogId " +
                                    "AND availability.status = 'В наличии'";
                    NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                    command.Parameters.AddWithValue("@catalogId", catalogId);

                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        availableCount = Convert.ToInt32(result);
                    }

                    return availableCount;
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show($"Ошибка при подсчете доступных экземпляров: {ex.Message}");
                    return 0;
                }
            }
        }

        public string GetCopyBookCondition(int copyId)
        {
            string condition = null;
            using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                try
                {
                    connection.Open();
                    string sqlExp = "SELECT \"condition\" FROM copy_book WHERE copy_id = @copyId";
                    NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                    command.Parameters.AddWithValue("@copyId", copyId);

                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        condition = Convert.ToString(result);
                    }

                    return condition;
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show($"Ошибка при получении состояния экземпляра книги: {ex.Message}");
                    return null;
                }
            }
        }

        public bool UpdateCopyBookCondition(int copyId, string newCondition)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                try
                {
                    connection.Open();
                    string sqlExp = "UPDATE copy_book SET \"condition\" = @newCondition WHERE copy_id = @copyId";
                    NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                    command.Parameters.AddWithValue("@copyId", copyId);
                    command.Parameters.AddWithValue("@newCondition", newCondition);

                    int rowsAffected = command.ExecuteNonQuery();

                    return rowsAffected > 0;
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show($"Ошибка при обновлении состояния экземпляра книги: {ex.Message}");
                    return false;
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        public int AddCopyBook(CopyBook copyBook)
        {
            using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                connection.Open();

                int availabilityId;
                using (var cmd = new NpgsqlCommand("SELECT availability_id FROM availability WHERE status = @status", connection))
                {
                    cmd.Parameters.AddWithValue("status", copyBook.Status);
                    var result = cmd.ExecuteScalar();
                    availabilityId = result != null ? Convert.ToInt32(result) : 1;
                }

                using (var cmd = new NpgsqlCommand(@"INSERT INTO copy_book (
                                                        delivery_date, condition, catalog_id, 
                                                        availability_id) 
                                                    VALUES (
                                                        @delivery_date, @condition, 
                                                        (SELECT catalog_id FROM catalog_books WHERE book_name = @book_name),
                                                        @availability_id
                                                    )
                                                    RETURNING copy_id;", connection))
                {
                    cmd.Parameters.AddWithValue("delivery_date", copyBook.DeliveryDate);
                    cmd.Parameters.AddWithValue("condition", copyBook.Condition);
                    cmd.Parameters.AddWithValue("book_name", copyBook.BookName);
                    cmd.Parameters.AddWithValue("availability_id", availabilityId);

                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        public bool AddCopyBook(CopyBook copyBook, int catalogId)
        {
            using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                connection.Open();

                using (var cmd = new NpgsqlCommand(@"
            INSERT INTO copy_book (delivery_date, condition, catalog_id, availability_id)
            VALUES (@delivery_date, @condition, @catalog_id, 1)
            RETURNING copy_id", connection))
                {
                    cmd.Parameters.AddWithValue("delivery_date", copyBook.DeliveryDate);
                    cmd.Parameters.AddWithValue("condition", copyBook.Condition);
                    cmd.Parameters.AddWithValue("catalog_id", catalogId);

                    var result = cmd.ExecuteScalar();
                    return result != null && result != DBNull.Value;
                }
            }
        }

        public bool DeleteCopyBook(int copyId)
        {
            using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                connection.Open();

                using (var cmd = new NpgsqlCommand(@"
                                    DELETE FROM copy_book 
                                    WHERE copy_id = @copy_id", connection))
                {
                    cmd.Parameters.AddWithValue("copy_id", copyId);
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
        }
    }
}
