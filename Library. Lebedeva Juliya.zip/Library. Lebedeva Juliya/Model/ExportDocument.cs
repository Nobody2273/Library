﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Excel = Microsoft.Office.Interop.Excel;

namespace Library.Lebedeva_Juliya.Model
{
    internal class ExportDocument
    {
        private string GetReaderFullNameById(int readerId)
        {
            try
            {
                var allReaders = new ReaderFromDb().LoadReaders();

                var reader = allReaders.FirstOrDefault(r => r.ReaderId == readerId);

                if (reader != null)
                {
                    return $"{reader.Lastname} {reader.Firstname}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при получении имени читателя: {ex.Message}");
            }

            return "Неизвестный читатель";
        }

        public void ExportReaderCardsToExcel(IEnumerable<dynamic> readerCards)
        {
            try
            {
                Excel.Application oXL = new Excel.Application();
                Excel._Workbook oWB = oXL.Workbooks.Add(Missing.Value);
                Excel._Worksheet oSheet = (Excel._Worksheet)oWB.ActiveSheet;

                oSheet.Cells[1, 1] = "№";
                oSheet.Cells[1, 2] = "Название книги";
                oSheet.Cells[1, 3] = "Автор";
                oSheet.Cells[1, 4] = "Издательство";
                oSheet.Cells[1, 5] = "Жанр";
                oSheet.Cells[1, 6] = "Номер экземпляра";
                oSheet.Cells[1, 7] = "Дата выдачи";
                oSheet.Cells[1, 8] = "Срок возврата";
                oSheet.Cells[1, 9] = "Дата возврата";
                oSheet.Cells[1, 10] = "Статус";

                string readerNameForFile = "Читатель";
                if (readerCards.Any() && readerCards.First().Card?.Reader_id != null)
                {
                    int readerId = readerCards.First().Card.Reader_id;
                    readerNameForFile = GetReaderFullNameById(readerId)
                        .Replace(" ", "_")
                        .Replace(".", "");
                }

                int row = 2;
                foreach (var card in readerCards)
                {
                    oSheet.Cells[row, 1] = row - 1;
                    oSheet.Cells[row, 2] = card.Book?.Book_name ?? "Не указано";
                    oSheet.Cells[row, 3] = $"{card.Book?.Lastname_author ?? ""} {card.Book?.Firstname_author ?? ""} {card.Book?.Patronymic_author ?? ""}".Trim();
                    oSheet.Cells[row, 4] = card.Book?.Publisher ?? "Не указано";
                    oSheet.Cells[row, 5] = card.Book?.Genre ?? "Не указано";
                    oSheet.Cells[row, 6] = card.Card?.Copy_id ?? "Не указано";
                    oSheet.Cells[row, 7] = card.Card?.Opening_date.ToString("dd.MM.yyyy") ?? "Не указано";
                    oSheet.Cells[row, 8] = card.Card != null ? $"{card.Card.Return_period} дней" : "Не указано";
                    oSheet.Cells[row, 9] = card.Card?.Return_date != null
                        ? ((DateTime)card.Card.Return_date).ToString("dd.MM.yyyy")
                        : "Не возвращена";

                    string status = "Активна";
                    if (card.Card?.Is_returned == true)
                        status = "Возвращена";
                    else if (card.IsOverdue)
                        status = $"Просрочена на {card.OverdueDays} д.";
                    else if (card.Card?.Extension_book == true)
                        status = "Продлена";

                    oSheet.Cells[row, 10] = status;
                    row++;
                }

                Excel.Range headerRange = oSheet.get_Range("A1", "J1");
                headerRange.Font.Bold = true;
                headerRange.Interior.Color = Excel.XlRgbColor.rgbLightGray;
                headerRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                headerRange.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;

                Excel.Range dataRange = oSheet.get_Range("A1", $"J{row - 1}");
                dataRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                dataRange.Borders.Weight = Excel.XlBorderWeight.xlThin;
                dataRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                dataRange.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;

                oSheet.Columns.AutoFit();

                string documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                string fileName = $"Выдача_книг_{readerNameForFile}_{DateTime.Now:dd.MM.yyyy}.xlsx";
                string filePath = System.IO.Path.Combine(documentsPath, fileName);

                oWB.SaveAs(filePath);
                oWB.Close();
                oXL.Quit();

                MessageBox.Show($"Данные успешно экспортированы в файл:\n{filePath}",
                    "Экспорт завершен",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                System.Diagnostics.Process.Start(filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте в Excel:\n{ex.Message}",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }
    }
}
