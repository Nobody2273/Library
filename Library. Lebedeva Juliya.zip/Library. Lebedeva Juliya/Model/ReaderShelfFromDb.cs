﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Lebedeva_Juliya.Classes;
using Npgsql;
using System.Windows;

namespace Library.Lebedeva_Juliya.Model
{
    internal class ReaderShelfFromDb
    {
        public bool AddBookToShelf(int readerId, int catalogId)
        {
            try
            {
                if (IsBookOnShelf(readerId, catalogId))
                {
                    return false;
                }

                using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connection.Open();

                    var insertCmd = new NpgsqlCommand(
                       @"INSERT INTO reader_shelf (reader_id, catalog_id, marked_for_visit) 
                VALUES (@readerId, @catalogId, FALSE);",
                        connection);
                    insertCmd.Parameters.AddWithValue("@readerId", readerId);
                    insertCmd.Parameters.AddWithValue("@catalogId", catalogId);

                    return insertCmd.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении книги на полку: {ex.Message}");
                return false;
            }
        }

        // Проверка наличия книги на полке
        public bool IsBookOnShelf(int readerId, int catalogId)
        {
            try
            {
                using (var connection = new NpgsqlConnection(DbConnection.connectionStr))
                {
                    connection.Open();

                    var cmd = new NpgsqlCommand(
                        "SELECT COUNT(*) FROM reader_shelf WHERE reader_id = @readerId AND catalog_id = @catalogId",
                        connection);
                    cmd.Parameters.AddWithValue("@readerId", readerId);
                    cmd.Parameters.AddWithValue("@catalogId", catalogId);

                    return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при проверке наличия книги на полке: {ex.Message}");
                return false;
            }
        }

        public bool DeleteFromReaderShelf(int catalogId, int readerId)
        {
            NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr);

            try
            {
                connection.Open();
                string sqlExp = "DELETE FROM reader_shelf WHERE catalog_id = @catalogId AND reader_id = @readerId;";

                NpgsqlCommand command = new NpgsqlCommand(sqlExp, connection);
                command.Parameters.AddWithValue("@catalogId", catalogId);
                command.Parameters.AddWithValue("@readerId", readerId);

                int rowsAffected = command.ExecuteNonQuery();

                return rowsAffected > 0;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show($"Ошибка при удалении книги с полки: {ex.Message}");
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        // Проверка статуса книги
        public bool GetVisitStatus(int catalogId, int readerId)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                try
                {
                    connection.Open();
                    string sql = @"SELECT marked_for_visit 
                         FROM reader_shelf 
                         WHERE catalog_id = @catalogId 
                         AND reader_id = @readerId";

                    using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@catalogId", catalogId);
                        command.Parameters.AddWithValue("@readerId", readerId);

                        object result = command.ExecuteScalar();
                        return result != null && (bool)result;
                    }
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show($"Ошибка получения статуса: {ex.Message}");
                    return false;
                }
            }
        }

        public bool UpdateVisitStatus(int catalogId, int readerId, bool newStatus)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection(DbConnection.connectionStr))
            {
                try
                {
                    connection.Open();
                    string sql = @"UPDATE reader_shelf 
                         SET marked_for_visit = @newStatus
                         WHERE catalog_id = @catalogId
                         AND reader_id = @readerId";

                    using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@newStatus", newStatus);
                        command.Parameters.AddWithValue("@catalogId", catalogId);
                        command.Parameters.AddWithValue("@readerId", readerId);

                        int rowsAffected = command.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show($"Ошибка обновления статуса: {ex.Message}");
                    return false;
                }
            }
        }
    }
}
