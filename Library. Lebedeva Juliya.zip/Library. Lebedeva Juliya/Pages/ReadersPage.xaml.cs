﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Classes;
using Library.Lebedeva_Juliya.Model;

namespace Library.Lebedeva_Juliya.Pages
{
    /// <summary>
    /// Логика взаимодействия для ReadersPage.xaml
    /// </summary>
    public partial class ReadersPage : Page
    {
        public List<Reader> readers { get; set; } = new List<Reader>();
        ReaderFromDb readerFromDb = new ReaderFromDb();

        ReaderShelfFromDb readerShelfFromDb = new ReaderShelfFromDb();
        CardOfReaderFromDb cardOfReaderFromDb = new CardOfReaderFromDb();
        public ReadersPage()
        {
            InitializeComponent();
            DataContext = this;
            Loaded += Readers_page_Loaded;
        }
        private void ViewAllReaders()
        {
            readers = readerFromDb.LoadReaders();
            foreach (var reader in readers)
            {
                reader.UnreturnedBooksCount = cardOfReaderFromDb.GetUnreturnedBooksCount(reader.ReaderId);
            }
            ApplySearchFilter();
        }
        private void ApplySearchFilter(string searchText = null)
        {
            if (string.IsNullOrWhiteSpace(searchText) || searchText == "Поиск по ФИО...")
            {
                list_readers.ItemsSource = readers;
            }
            else
            {
                var filtered = readers.Where(r =>
            (r.Lastname != null && r.Lastname.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0) ||
            (r.Firstname != null && r.Firstname.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0) ||
            (r.Patronymic != null && r.Patronymic.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0)
            ).ToList();

                list_readers.ItemsSource = filtered;
            }
        }
        private void Readers_page_Loaded(object sender, RoutedEventArgs e)
        {
            ViewAllReaders();
        }

        private void list_readers_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (list_readers.SelectedItem is Reader selectedReader)
            {
                int unreturnedBooksCount = cardOfReaderFromDb.GetUnreturnedBooksCount(selectedReader.ReaderId);

                if (unreturnedBooksCount >= 5)
                {
                    MessageBox.Show($"Читатель {selectedReader.Lastname} {selectedReader.Firstname} " +
                                  $"уже имеет {unreturnedBooksCount} книг на руках.\n" +
                                  "Максимальное количество - 5 книг одновременно.",
                                  "Ограничение выдачи",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Warning);
                    return;
                }
                NavigationService.Navigate(new IssueBookPage(selectedReader));
            }
        }

        private void tB_search_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tB_search.Text))
            {
                tB_search.Text = "Поиск по ФИО...";
                tB_search.Foreground = Brushes.Gray;

                ApplySearchFilter();
            }
        }

        private void tB_search_GotFocus(object sender, RoutedEventArgs e)
        {
            if (tB_search.Text == "Поиск по ФИО...")
            {
                tB_search.Text = "";
                tB_search.Foreground = Brushes.Black;
            }
        }

        private void tB_search_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (tB_search.Text == "Поиск по ФИО...") return;
            ApplySearchFilter(tB_search.Text.Trim());
        }

        private void btn_cardOfReader_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is int readerId)
            {
                var reader = readers.FirstOrDefault(r => r.ReaderId == readerId);
                if (reader != null)
                {
                    NavigationService.Navigate(new ReaderCardPage(reader));
                }
                else
                {
                    MessageBox.Show("Ошибка: Читатель не найден.");
                }
            }
        }
    }
}
