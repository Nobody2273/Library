﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Classes;
using Library.Lebedeva_Juliya.Model;
using Library.Lebedeva_Juliya.Windows;
using static Library.Lebedeva_Juliya.Model.UserFromDb;

namespace Library.Lebedeva_Juliya.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProfilPage.xaml
    /// </summary>
    public partial class ProfilPage : Page
    {
        private UserFromDb userFromDb = new UserFromDb();
        UserProfil profile;
        private int user_id;
        private bool _isAdminView;
        private PostFromDb _postFromDb = new PostFromDb();
        private List<Post> _allPosts;

        public ProfilPage(int userId, bool isAdminView = false)
        {
            InitializeComponent();
            user_id = userId;
            _isAdminView = isAdminView;
            _allPosts = _postFromDb.GetAllPosts();
            LoadProfile();
        }

        private void LoadProfile()
        {
            try
            {
                profile = userFromDb.GetUserProfile(user_id);
                if (profile != null)
                {
                    DataContext = profile;

                    spReaderInfo.Visibility = profile.IsReader ? Visibility.Visible : Visibility.Collapsed;
                    spEmployeeInfo.Visibility = _isAdminView ? Visibility.Visible : Visibility.Collapsed;

                    btnEditEmployee.Visibility = _isAdminView ? Visibility.Visible : Visibility.Collapsed;
                    btnSaveEmployee.Visibility = Visibility.Collapsed;
                    btnCancelEmployee.Visibility = Visibility.Collapsed;

                    btnDeleteEmployee.Visibility = _isAdminView && profile.IsEmployee ? Visibility.Visible : Visibility.Collapsed;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки профиля: {ex.Message}");
            }
        }

        private void ToggleEditModeUser(bool isEdit)
        {
            tbEmail.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            tbEditEmail.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            tbPhone.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            tbEditPhone.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;

            btnEditUser.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            btnSaveUser.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            btnCancelUser.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
        }

        private void ToggleEditModePersonal(bool isEdit)
        {
            tbDocSeries.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            tbEditDocSeries.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            tbDocNumber.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            tbEditDocNumber.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            tbDocDate.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            dpEditDocDate.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            tbDocIssuedBy.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            tbEditDocIssuedBy.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;

            btnEditPersonal.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            btnSavePersonal.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            btnCancelPersonal.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
        }

        private void ToggleEditModeReader(bool isEdit)
        {
            tbReaderLastName.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            tbEditReaderLastName.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            tbReaderFirstName.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            tbEditReaderFirstName.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            tbReaderPatronymic.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            tbEditReaderPatronymic.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            tbReaderBirthDate.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            dpEditReaderBirthDate.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            tbReaderAddress.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            tbEditReaderAddress.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;

            btnEditReader.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            btnSaveReader.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            btnCancelReader.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
        }

        private void ToggleEditModeEmployee(bool isEdit)
        {
            tbEmployeeLastName.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            tbEditEmployeeLastName.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            tbEmployeeFirstName.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            tbEditEmployeeFirstName.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            tbEmployeePatronymic.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            tbEditEmployeePatronymic.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            tbEmployeePost.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            cbEditEmployeePost.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;

            if (isEdit)
            {
                cbEditEmployeePost.ItemsSource = _allPosts;
                cbEditEmployeePost.DisplayMemberPath = "PostName";
                cbEditEmployeePost.SelectedValuePath = "PostId";

                var currentPost = _allPosts.FirstOrDefault(p => p.PostName == profile.Position);
                if (currentPost != null)
                {
                    cbEditEmployeePost.SelectedValue = currentPost.PostId;
                }
            }

            btnEditEmployee.Visibility = isEdit ? Visibility.Collapsed : Visibility.Visible;
            btnSaveEmployee.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
            btnCancelEmployee.Visibility = isEdit ? Visibility.Visible : Visibility.Collapsed;
        }

        private void btnEditEmployee_Click(object sender, RoutedEventArgs e)
        {
            ToggleEditModeEmployee(true);
        }

        private void btnSaveEmployee_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cbEditEmployeePost.SelectedItem != null)
                {
                    var selectedPost = (Post)cbEditEmployeePost.SelectedItem;
                    profile.Position = selectedPost.PostName;
                }

                profile.LastName = tbEditEmployeeLastName.Text;
                profile.FirstName = tbEditEmployeeFirstName.Text;
                profile.Patronymic = tbEditEmployeePatronymic.Text;

                if (userFromDb.UpdateUserProfile(profile))
                {
                    LoadProfile();
                    ToggleEditModeEmployee(false);
                    MessageBox.Show("Данные успешно сохранены", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancelEmployee_Click(object sender, RoutedEventArgs e)
        {
            DataContext = profile;
            ToggleEditModeEmployee(false);
            LoadProfile();
        }

        private void btnEditUser_Click(object sender, RoutedEventArgs e)
        {
            ToggleEditModeUser(true);
        }

        private void btnSaveUser_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!userFromDb.IsEmailValid(tbEditEmail.Text))
                {
                    MessageBox.Show("Указан некорректный email адрес", "Ошибка",
                                   MessageBoxButton.OK, MessageBoxImage.Error);
                    tbEditEmail.BorderBrush = Brushes.Red;
                    tbEditEmail.BorderThickness = new Thickness(1);
                    return;
                }

                if (tbEditEmail.Text != profile.Email &&
                    !userFromDb.IsEmailUnique(tbEditEmail.Text))
                {
                    MessageBox.Show("Пользователь с таким email уже существует", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                profile.Email = tbEditEmail.Text;
                profile.Phone = tbEditPhone.Text;

                if (userFromDb.UpdateUserProfile(profile))
                {
                    LoadProfile();
                    ToggleEditModeUser(false);
                    MessageBox.Show("Данные успешно сохранены", "Успех",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка",
                               MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancelUser_Click(object sender, RoutedEventArgs e)
        {
            DataContext = profile;
            ToggleEditModeUser(false);
            LoadProfile();
        }

        private void btnEditPersonal_Click(object sender, RoutedEventArgs e)
        {
            ToggleEditModePersonal(true);
        }

        private void btnSavePersonal_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (userFromDb.UpdateUserProfile(profile))
                {
                    LoadProfile();
                    ToggleEditModePersonal(false);
                    MessageBox.Show("Данные успешно сохранены", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancelPersonal_Click(object sender, RoutedEventArgs e)
        {
            DataContext = profile;
            ToggleEditModePersonal(false);
            LoadProfile();
        }

        private void btnEditReader_Click(object sender, RoutedEventArgs e)
        {
            ToggleEditModeReader(true);
        }

        private void btnSaveReader_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (userFromDb.UpdateUserProfile(profile))
                {
                    LoadProfile();
                    ToggleEditModeReader(false);
                    MessageBox.Show("Данные успешно сохранены", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancelReader_Click(object sender, RoutedEventArgs e)
        {
            DataContext = profile;
            ToggleEditModeReader(false);
            LoadProfile();
        }

        private void btnDeleteEmployee_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
                                            "Вы уверены, что хотите полностью удалить этого сотрудника? Это действие нельзя отменить.",
                                            "Подтверждение удаления",
                                            MessageBoxButton.YesNo,
                                            MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    if (userFromDb.DeleteEmployee(user_id))
                    {
                        MessageBox.Show("Сотрудник успешно удален", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                        if (NavigationService.CanGoBack)
                        {
                            NavigationService.GoBack();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Не удалось удалить сотрудника", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении сотрудника: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
