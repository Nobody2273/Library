﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Classes;
using Library.Lebedeva_Juliya.Model;
using Library.Lebedeva_Juliya.Windows;

namespace Library.Lebedeva_Juliya.Pages
{
    /// <summary>
    /// Логика взаимодействия для IssueBookPage.xaml
    /// </summary>
    public partial class IssueBookPage : Page
    {
        private Reader _reader;
        private List<Book> MarkedBooks;
        private CardOfReaderFromDb _cardOfReaderFromDb = new CardOfReaderFromDb();
        private ReaderShelfFromDb readerShelfFromDb = new ReaderShelfFromDb();
        private CopyBookFromDb copyBookFromDb = new CopyBookFromDb();
        private EmployeeFromDb employeeFromDb = new EmployeeFromDb();
        private List<CopyBook> availableCopies = new List<CopyBook>();
        private User _currentUser;
        BookFromDb bookFromDb = new BookFromDb();

        // Хранение выбранных экземпляров 
        private Dictionary<int, List<CopyBook>> SelectedCopies = new Dictionary<int, List<CopyBook>>();

        // Хранение доступных экземпляров для каждой книги 
        private Dictionary<int, List<CopyBook>> AvailableCopiesByBook = new Dictionary<int, List<CopyBook>>();

        // Конструктор при обычном запуске
        public IssueBookPage(Reader reader)
        {
            InitializeComponent();
            _reader = reader;
            _currentUser = AuthorizationWindow.currentUser;
            DataContext = this;

            tB_readerName.Text = $"{reader.Lastname} {reader.Firstname}";
            tB_registrationDate.Text = reader.RegistrationDate.ToString("dd.MM.yyyy");

            LoadMarkedBooks();
        }

        // Конструктор при добавлении книг
        public IssueBookPage(Reader reader, List<Book> MarkedBooks, Dictionary<int, List<CopyBook>> SelectedCopiesBook)
        {
            InitializeComponent();
            _reader = reader;
            _currentUser = AuthorizationWindow.currentUser;
            SelectedCopies = SelectedCopiesBook;
            DataContext = this;

            tB_readerName.Text = $"{reader.Lastname} {reader.Firstname}";
            tB_registrationDate.Text = reader.RegistrationDate.ToString("dd.MM.yyyy");

            LoadAddedMarkedBooks(MarkedBooks);
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        { }

        private void UpdateSelectedCopiesDescription()
        {
            int totalSelected = 0;

            foreach (var book in MarkedBooks)
            {
                if (SelectedCopies.ContainsKey(book.Catalog_id))
                {
                    int count = SelectedCopies[book.Catalog_id].Count;
                    book.SelectedCopyDescription = count > 0 ? $"Выбрано экземпляров: {count}" : null;
                    totalSelected += count;
                }
                else
                {
                    book.SelectedCopyDescription = null;
                }
            }
            tB_copyBookCount.Text = totalSelected.ToString();
            lvMarkedBooks.Items.Refresh();
        }

        private void LoadMarkedBooks()
        {
            try
            {
                var allBooks = bookFromDb.LoadBookByReader(_reader.ReaderId);

                MarkedBooks = allBooks
                    .Where(book =>
                    {
                        book.MarkedForVisit = readerShelfFromDb.GetVisitStatus(book.Catalog_id, _reader.ReaderId);
                        return book.MarkedForVisit;
                    })
                    .ToList();

                lvMarkedBooks.ItemsSource = MarkedBooks;
                tB_bookCount.Text = MarkedBooks.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке отмеченных книг: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                NavigationService.GoBack();
            }
        }

        // Загрузка после добавления книг
        private void LoadAddedMarkedBooks(List<Book> _markedBooks)
        {
            try
            {
                MarkedBooks = _markedBooks.ToList();
                lvMarkedBooks.ItemsSource = MarkedBooks;
                tB_bookCount.Text = MarkedBooks.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке отмеченных книг: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                NavigationService.GoBack();
            }
        }

        private void btnRemoveFromList_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.CommandParameter is Book bookToRemove)
            {
                try
                {
                    MessageBoxResult result = MessageBox.Show(
                        $"Вы действительно хотите удалить книгу '{bookToRemove.Book_name}' из списка?",
                        "Подтверждение удаления",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question);

                    if (result != MessageBoxResult.Yes)
                        return;

                    MarkedBooks.Remove(bookToRemove);
                    if (SelectedCopies.ContainsKey(bookToRemove.Catalog_id))
                    {
                        SelectedCopies.Remove(bookToRemove.Catalog_id);
                    }

                    if (lvMarkedBooks.SelectedItem == bookToRemove)
                    {
                        lvBookCopies.ItemsSource = null;
                        tB_copyBookName.Text = "Экземпляры книги";
                    }

                    lvMarkedBooks.ItemsSource = null;
                    lvMarkedBooks.ItemsSource = MarkedBooks;
                    tB_bookCount.Text = MarkedBooks.Count.ToString();
                    UpdateSelectedCopiesDescription();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении книги: {ex.Message}", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void btnRemoveCopy_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.CommandParameter is CopyBook copyToRemove &&
                lvMarkedBooks.SelectedItem is Book selectedBook)
            {
                if (SelectedCopies.ContainsKey(selectedBook.Catalog_id))
                {
                    SelectedCopies[selectedBook.Catalog_id].Remove(copyToRemove);
                    UpdateSelectedCopiesDescription();
                }
            }
        }

        private void LoadBookCopies(Book book)
        {
            try
            {
                if (AvailableCopiesByBook.ContainsKey(book.Catalog_id))
                {
                    availableCopies = AvailableCopiesByBook[book.Catalog_id];
                }
                else
                {
                    availableCopies = copyBookFromDb.LoadCopyBooks()
                        .Where(cb => cb.BookName == book.Book_name && cb.Status == "В наличии")
                        .ToList();

                    AvailableCopiesByBook[book.Catalog_id] = availableCopies;
                }

                lvBookCopies.ItemsSource = availableCopies;
                tB_copyBookName.Text = $"Экземпляры книги {book.Book_name}";

                if (SelectedCopies.ContainsKey(book.Catalog_id))
                {
                    foreach (var copy in availableCopies)
                    {
                        copy.MarkedForIssue = SelectedCopies[book.Catalog_id].Any(c => c.CopyId == copy.CopyId);
                    }
                }
                lvBookCopies.Items.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке экземпляров книги: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void lvMarkedBooks_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lvMarkedBooks.SelectedItem is Book selectedBook)
            {
                LoadBookCopies(selectedBook);
                lvBookCopies.Items.Refresh();
            }
        }

        private void lvBookCopies_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (lvBookCopies.SelectedItem is CopyBook selectedCopyBook &&
           lvMarkedBooks.SelectedItem is Book selectedBook)
            {
                int alreadyIssuedBooksCount = _cardOfReaderFromDb.GetUnreturnedBooksCount(_reader.ReaderId);

                int totalSelected = 0;
                foreach (var book in MarkedBooks)
                {
                    if (SelectedCopies.ContainsKey(book.Catalog_id))
                    {
                        totalSelected += SelectedCopies[book.Catalog_id].Count;
                    }
                }
                if (!SelectedCopies.ContainsKey(selectedBook.Catalog_id))
                {
                    SelectedCopies[selectedBook.Catalog_id] = new List<CopyBook>();
                }
                if (!SelectedCopies[selectedBook.Catalog_id].Any(c => c.CopyId == selectedCopyBook.CopyId))
                {
                    totalSelected++;
                }

                int totalAfterIssue = alreadyIssuedBooksCount + totalSelected;

                if (totalAfterIssue > 5)
                {
                    MessageBox.Show($"Нельзя выдать больше 5 экземпляров. У читателя уже {alreadyIssuedBooksCount} экземпляр(ов).",
                        "Превышение лимита", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (!SelectedCopies.ContainsKey(selectedBook.Catalog_id))
                {
                    SelectedCopies[selectedBook.Catalog_id] = new List<CopyBook>();
                }

                if (!SelectedCopies[selectedBook.Catalog_id].Any(c => c.CopyId == selectedCopyBook.CopyId))
                {
                    selectedCopyBook.MarkedForIssue = true;
                    SelectedCopies[selectedBook.Catalog_id].Add(selectedCopyBook);
                    UpdateSelectedCopiesDescription();
                }
                else
                {
                    selectedCopyBook.MarkedForIssue = false;
                    SelectedCopies[selectedBook.Catalog_id].RemoveAll(c => c.CopyId == selectedCopyBook.CopyId);
                    UpdateSelectedCopiesDescription();
                }

                lvBookCopies.Items.Refresh();
            }

        }

        private void btnIssueBooks_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var employee = employeeFromDb.GetEmployeeByUserId(_currentUser.UserId);
                if (employee == null)
                {
                    MessageBox.Show("Не удалось определить сотрудника", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                int totalCopiesToIssue = SelectedCopies.Sum(pair => pair.Value.Count);
                int alreadyIssuedBooksCount = _cardOfReaderFromDb.GetUnreturnedBooksCount(_reader.ReaderId);
                int totalAfterIssue = alreadyIssuedBooksCount + totalCopiesToIssue;

                if (totalAfterIssue > 5)
                {
                    int canIssue = 5 - alreadyIssuedBooksCount;
                    MessageBox.Show($"Читатель уже имеет {alreadyIssuedBooksCount} книг(и). " +
                        $"Можно выдать только {canIssue} экземпляров, чтобы не превысить лимит в 5 книг.",
                        "Превышение лимита",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                foreach (var book in MarkedBooks)
                {
                    if (!SelectedCopies.ContainsKey(book.Catalog_id) ||
                        !SelectedCopies[book.Catalog_id].Any())
                    {
                        MessageBox.Show($"Не выбран ни один экземпляр для книги '{book.Book_name}'.", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }

                int issuedCount = 0;
                foreach (var book in MarkedBooks)
                {
                    foreach (var copy in SelectedCopies[book.Catalog_id])
                    {
                        _cardOfReaderFromDb.IssueBook(
                            copyId: copy.CopyId,
                            readerId: _reader.ReaderId,
                            employeeId: employee.EmployeeId,
                            issueTypeId: 1,
                            returnPeriod: 30
                        );
                        issuedCount++;
                    }
                }

                MessageBox.Show($"Успешно выдано {issuedCount} экземпляров книг", "Результат",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                FrameClass.bookFrame.Navigate(new Pages.ReadersPage());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при выдаче книг: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnAddBook_Click(object sender, RoutedEventArgs e)
        {
            int alreadyIssuedBooksCount = _cardOfReaderFromDb.GetUnreturnedBooksCount(_reader.ReaderId);
            int booksToAddCount = MarkedBooks.Count;
            int totalAfterAdd = alreadyIssuedBooksCount + booksToAddCount;

            if (totalAfterAdd >= 5)
            {
                int canAdd = 5 - alreadyIssuedBooksCount;
                MessageBox.Show($"Читатель уже имеет {alreadyIssuedBooksCount} книг(и). " +
                    $"Можно добавить только {canAdd} книг(и), чтобы не превысить лимит в 5 книг.",
                    "Превышение лимита",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Pages.CatalogPage catalogPage = new Pages.CatalogPage(_reader, MarkedBooks, SelectedCopies);
            FrameClass.bookFrame.Navigate(catalogPage);
        }

        private void btn_Back_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.bookFrame.Navigate(new Pages.ReadersPage());
        }
    }
}