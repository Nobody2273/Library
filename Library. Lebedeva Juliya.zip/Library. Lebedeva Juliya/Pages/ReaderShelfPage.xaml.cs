﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Classes;
using Library.Lebedeva_Juliya.Model;
using Library.Lebedeva_Juliya.Windows;

namespace Library.Lebedeva_Juliya.Pages
{
    /// <summary>
    /// Логика взаимодействия для ReaderShelfPage.xaml
    /// </summary>
    public partial class ReaderShelfPage : Page
    {
        public List<ReaderShelf> shelfBooks { get; set; } = new List<ReaderShelf>();
        ReaderShelfFromDb readerShelfFromDb = new ReaderShelfFromDb();
        ReaderFromDb readerFromDb = new ReaderFromDb();
        public List<Book> books { get; set; } = new List<Book>();
        BookFromDb bookFromDb = new BookFromDb();

        CopyBookFromDb copyBookFromDb = new CopyBookFromDb();

        int currentReader;
        int bookMarked = 0;

        public ReaderShelfPage()
        {
            InitializeComponent();
            currentReader = readerFromDb.GetReaderId(AuthorizationWindow.currentUser.UserId);
        }
        private void readerShelf_page_Loaded(object sender, RoutedEventArgs e)
        {
            ViewAllBooksShelf();
        }
        private void ViewAllBooksShelf()
        {
            if (currentReader > 0)
            {
                bookMarked = 0;
                books = bookFromDb.LoadBookByReader(currentReader);

                foreach (var book in books)
                {
                    book.AvailableCopies = copyBookFromDb.CountAvailableCopies(book.Catalog_id);
                    book.MarkedForVisit = readerShelfFromDb.GetVisitStatus(book.Catalog_id, currentReader);
                    if (book.MarkedForVisit && book.AvailableCopies <= 0)
                    {
                        readerShelfFromDb.UpdateVisitStatus(book.Catalog_id, currentReader, false);
                        book.MarkedForVisit = false;
                    }
                    if (book.MarkedForVisit == true)
                        bookMarked += 1;
                }
                var markedBooks = books?.Where(b => b.MarkedForVisit).ToList();
                var regularBooks = books?.Where(b => !b.MarkedForVisit).ToList();
                markedBooksSection.Visibility = bookMarked > 0 ? Visibility.Visible : Visibility.Collapsed;
                itC_markedBooks.ItemsSource = bookMarked > 0 ? markedBooks : null;
                itC_shelfBooks.ItemsSource = regularBooks;
                itC_shelfBooks.Visibility = Visibility.Visible;

                tB_allBooks.Text = "Всего книг: " + books.Count;
                tB_bookMarked.Text = "| Отмечено к посещению: " + bookMarked;

                if (books == null || !books.Any())
                    MessageBox.Show("На вашей полке пока нет книг. Ознакомьтесь с нашим каталогом", "Информация",
                        MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
                MessageBox.Show("Не удалось определить ваш профиль читателя", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void btn_delShelfBook_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.CommandParameter is Book book)
            {
                var result = MessageBox.Show($"Вы действительно хотите убрать книгу '{book.Book_name}' с полки?",
                                           "Подтверждение",
                                           MessageBoxButton.YesNo,
                                           MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    bool isDelete = readerShelfFromDb.DeleteFromReaderShelf(book.Catalog_id, currentReader);

                    if (isDelete)
                    {
                        MessageBox.Show($"Вы убрали книгу '{book.Book_name}' с полки",
                                      "Успех",
                                      MessageBoxButton.OK,
                                      MessageBoxImage.Information);
                        ViewAllBooksShelf();
                    }
                    else
                    {
                        MessageBox.Show("Не удалось убрать книгу с полки",
                                      "Ошибка",
                                      MessageBoxButton.OK,
                                      MessageBoxImage.Error);
                    }
                }
            }
        }

        private void btn_visitAdd_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.CommandParameter is Book book)
            {
                try
                {
                    bool currentStatus = book.MarkedForVisit;
                    bool newStatus = !currentStatus;

                    if (!currentStatus && newStatus && bookMarked >= 5)
                    {
                        MessageBox.Show(
                            $"Вы не можете отметить больше 5 книг для посещения.",
                            "Лимит превышен",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
                        return;
                    }

                    if (readerShelfFromDb.UpdateVisitStatus(book.Catalog_id, currentReader, newStatus))
                    {
                        book.MarkedForVisit = newStatus;
                        bookMarked += newStatus ? 1 : -1;

                        MessageBox.Show(newStatus
                            ? "Книга отмечена для посещения!"
                            : "Отметка о посещении снята",
                            "Статус обновлен");
                    }

                    ViewAllBooksShelf();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
                }
            }
        }
        private void ShowAboutBook(MouseButtonEventArgs e)
        {
            if ((e.OriginalSource as FrameworkElement)?.DataContext is Book selectedBook)
            {
                Pages.AboutBookPage aboutBookPage = new Pages.AboutBookPage(selectedBook);
                FrameClass.bookFrame.Navigate(aboutBookPage);
            }
        }

        private void itC_shelfBooks_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ShowAboutBook(e);
        }

        private void itC_markedBooks_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ShowAboutBook(e);
        }
    }
}
