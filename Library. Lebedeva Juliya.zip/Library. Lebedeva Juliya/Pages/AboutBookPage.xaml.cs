﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Classes;
using Library.Lebedeva_Juliya.Model;
using Library.Lebedeva_Juliya.Windows;

namespace Library.Lebedeva_Juliya.Pages
{
    /// <summary>
    /// Логика взаимодействия для AboutBookPage.xaml
    /// </summary>
    public partial class AboutBookPage : Page
    {
        private List<Book> _markedBooks;
        private Reader _reader;
        private Dictionary<int, List<CopyBook>> _selectedCopies;

        Book book;
        CopyBookFromDb copyBookFromDb = new CopyBookFromDb();
        ReaderShelfFromDb readerShelfFromDb = new ReaderShelfFromDb();
        ReaderFromDb readerFromDb = new ReaderFromDb();
        RoleFromDb roleFromDb = new RoleFromDb();
        public List<CopyBook> copyBooks { get; set; } = new List<CopyBook>();
        int currentReader;
        string role;

        public AboutBookPage()
        {
            InitializeComponent();
        }
        public AboutBookPage(Book selectedBook)
        {
            InitializeComponent();
            if (selectedBook != null)
            {
                book = selectedBook;
                this.DataContext = book;
            }
            currentReader = readerFromDb.GetReaderId(AuthorizationWindow.currentUser.UserId);

            role = roleFromDb.GetUserRole(AuthorizationWindow.currentUser.UserId);
            UpdateNavigationForRole(role);

        }
        public AboutBookPage(Book selectedBook, Reader reader, List<Book> MarkedBooks, Dictionary<int, List<CopyBook>> SelectedCopies)
        {
            InitializeComponent();
            if (selectedBook != null)
            {
                book = selectedBook;
                this.DataContext = book;
            }
            currentReader = readerFromDb.GetReaderId(AuthorizationWindow.currentUser.UserId);

            _markedBooks = MarkedBooks;
            _reader = reader;
            _selectedCopies = SelectedCopies;

            role = roleFromDb.GetUserRole(AuthorizationWindow.currentUser.UserId);
            UpdateNavigationForRole(role);
        }
        private void UpdateNavigationForRole(string role)
        {
            switch (role)
            {
                case "Библиотекарь":
                    spAdminButtons.Visibility = Visibility.Visible;
                    spCopyButtons.Visibility = Visibility.Visible;
                    if (_reader == null)
                    {
                        btnAddShelf.Visibility = Visibility.Hidden;
                    }
                    else
                        btnAddShelf.Content = "Добавить для выдачи";
                    break;

                case "Читатель":
                    spAdminButtons.Visibility = Visibility.Collapsed;
                    spCopyButtons.Visibility = Visibility.Collapsed;
                    break;
            }
        }
        private void btnAddCopy_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var newCopy = new CopyBook(
                    copyId: 0,
                    deliveryDate: DateTime.Now,
                    condition: "Новый",
                    bookName: book.Book_name,
                    status: "Доступен")
                {
                    MarkedForIssue = false
                };

                bool success = copyBookFromDb.AddCopyBook(newCopy, book.Catalog_id);

                if (success)
                {

                    copyBooks = copyBookFromDb.LoadCopyBooks()
                        .Where(cb => cb.BookName == book.Book_name)
                        .ToList();

                    for (int i = 0; i < copyBooks.Count; i++)
                    {
                        copyBooks[i].CopyNumber = i + 1;
                    }

                    list_copyBooks.ItemsSource = null;
                    list_copyBooks.ItemsSource = copyBooks;

                    book.AvailableCopies = copyBookFromDb.CountAvailableCopies(book.Catalog_id);

                    MessageBox.Show("Экземпляр книги успешно добавлен!", "Успех",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Не удалось добавить экземпляр книги", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении экземпляра: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnRemoveCopy_Click(object sender, RoutedEventArgs e)
        {
            if (list_copyBooks.SelectedItem == null)
            {
                MessageBox.Show("Выберите экземпляр для удаления", "Предупреждение",
                               MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            CopyBook selectedCopy = (CopyBook)list_copyBooks.SelectedItem;

            if (selectedCopy.Status == "Выдана")
            {
                MessageBox.Show("Нельзя удалить выданный экземпляр книги", "Ошибка",
                               MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            MessageBoxResult result = MessageBox.Show(
                $"Вы уверены, что хотите удалить экземпляр №{selectedCopy.CopyNumber} книги \"{book.Book_name}\"?",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    bool deleted = copyBookFromDb.DeleteCopyBook(selectedCopy.CopyId);

                    if (deleted)
                    {
                        ViewAllCopyBooks();
                        MessageBox.Show("Экземпляр книги успешно удален!", "Успех",
                                      MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        MessageBox.Show("Не удалось удалить экземпляр книги", "Ошибка",
                                      MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении экземпляра: {ex.Message}", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        private void btnEditBook_Click(object sender, RoutedEventArgs e)
        {
            if (book == null)
            {
                MessageBox.Show("Не удалось загрузить данные книги для редактирования.",
                               "Ошибка",
                               MessageBoxButton.OK,
                               MessageBoxImage.Error);
                return;
            }


            NavigationService.Navigate(new AddBookPage(book));
        }
        private void btnDeleteBook_Click(object sender, RoutedEventArgs e)
        {
            CardOfReaderFromDb cardOfReaderFromDb = new CardOfReaderFromDb();
            bool hasUnreturnedCopies = cardOfReaderFromDb.HasUnreturnedCopies(book.Catalog_id);

            if (hasUnreturnedCopies)
            {
                MessageBox.Show("Невозможно удалить книгу, так как у нее есть невозвращенные экземпляры.",
                                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            MessageBoxResult result = MessageBox.Show($"Вы уверены, что хотите удалить книгу \"{book.Book_name}\"?",
                                                    "Подтверждение удаления",
                                                    MessageBoxButton.YesNo,
                                                    MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                BookFromDb bookFromDb = new BookFromDb();
                bool deleted = bookFromDb.DeleteBook(book.Catalog_id);

                if (deleted)
                {
                    MessageBox.Show("Книга успешно удалена.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.GoBack();
                }
                else
                {
                    MessageBox.Show("Не удалось удалить книгу.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void aboutBook_Loaded(object sender, RoutedEventArgs e)
        {
            ViewAllCopyBooks();
            CheckIfBookOnShelf();
        }
        private void ViewAllCopyBooks()
        {
            book.AvailableCopies = copyBookFromDb.CountAvailableCopies(book.Catalog_id);
            if (book.AvailableCopies < 1)
            {
                btnAddShelf.Visibility = Visibility.Hidden;
            }

            copyBooks = copyBookFromDb.LoadCopyBooks().Where(cb => cb.BookName == book.Book_name).ToList();
            for (int i = 0; i < copyBooks.Count; i++)
            {
                copyBooks[i].CopyNumber = i + 1;
            }
            list_copyBooks.ItemsSource = copyBooks;

        }
        private void CheckIfBookOnShelf()
        {
            if (book != null && AuthorizationWindow.currentUser != null)
            {
                if (role == "Библиотекарь")
                {
                    bool isMarkedForIssue = _markedBooks != null &&
                              _markedBooks.Any(b => b.Catalog_id == book.Catalog_id);

                    if (isMarkedForIssue)
                    {
                        btnAddShelf.Content = "Книга уже в списке для выдачи";
                        btnAddShelf.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#95a5a6"));
                        btnAddShelf.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#7f8c8d"));
                        btnAddShelf.IsEnabled = false;
                        btnAddShelf.Cursor = Cursors.Arrow;
                        ToolTipService.SetToolTip(btnAddShelf, "Эта книга уже добавлена в список для выдачи");
                    }
                }
                else
                {
                    bool isOnShelf = readerShelfFromDb.IsBookOnShelf(currentReader, book.Catalog_id);

                    if (isOnShelf)
                    {
                        btnAddShelf.Content = "Книга уже есть на вашей полке читателя";
                        btnAddShelf.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#95a5a6"));
                        btnAddShelf.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#7f8c8d"));
                        btnAddShelf.IsEnabled = false;
                        btnAddShelf.Cursor = Cursors.Arrow;
                        ToolTipService.SetToolTip(btnAddShelf, "Эта книга уже добавлена на вашу полку");
                    }
                }
            }
        }

        private void btn_Back_Click(object sender, RoutedEventArgs e)
        {
            if (btnAddShelf.Content.ToString() == "Добавить для выдачи")
            {
                FrameClass.bookFrame.Navigate(new CatalogPage(_reader, _markedBooks, _selectedCopies));
            }
            else
                NavigationService.GoBack();
        }

        private void btnAddShelf_Click(object sender, RoutedEventArgs e)
        {
            if (btnAddShelf.Content.ToString() == "Добавить для выдачи")
            {
                CardOfReaderFromDb cardOfReaderFromDb = new CardOfReaderFromDb();
                int alreadyIssuedBooksCount = cardOfReaderFromDb.GetUnreturnedBooksCount(_reader.ReaderId);
                int booksToAddCount = _markedBooks.Count + 1;

                if (alreadyIssuedBooksCount + booksToAddCount > 5)
                {
                    int canAdd = 5 - alreadyIssuedBooksCount;
                    MessageBox.Show($"Читатель уже имеет {alreadyIssuedBooksCount} книг(и). " +
                        $"Можно добавить только {canAdd} книг(и), чтобы не превысить лимит в 5 книг.",
                        "Превышение лимита",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    FrameClass.bookFrame.Navigate(new IssueBookPage(_reader, _markedBooks, _selectedCopies));
                }
                else
                {
                    _markedBooks.Add(book);
                    MessageBox.Show("Книга добавлена в список для выдачи", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                int currentBook = book.Catalog_id;
                bool addShelf = readerShelfFromDb.AddBookToShelf(currentReader, currentBook);

                if (addShelf)
                    MessageBox.Show("Книга добавлена на вашу полку читателя!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                else
                    MessageBox.Show("Не удалось добавить книгу на вашу полку читателя",
                                   "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            CheckIfBookOnShelf();
        }
    }
}
