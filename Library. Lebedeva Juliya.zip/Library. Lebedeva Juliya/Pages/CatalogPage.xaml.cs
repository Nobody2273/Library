﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Classes;
using Library.Lebedeva_Juliya.Model;
using Library.Lebedeva_Juliya.Windows;

namespace Library.Lebedeva_Juliya.Pages
{
    /// <summary>
    /// Логика взаимодействия для CatalogPage.xaml
    /// </summary>
    public partial class CatalogPage : Page
    {
        private List<Book> _markedBooks;
        private Reader _reader;
        private Dictionary<int, List<CopyBook>> _selectedCopies;

        public List<Book> books { get; set; } = new List<Book>();
        BookFromDb bookFromDb = new BookFromDb();

        public static List<Genre> genres = new List<Genre>();
        GenreFromDb genreFromDb = new GenreFromDb();

        public static List<LanguageBook> languages = new List<LanguageBook>();
        LanguageFromDb languageFromDb = new LanguageFromDb();

        public static List<PublisherBook> publishers = new List<PublisherBook>();
        PublisherFromDb publisherFromDb = new PublisherFromDb();

        CopyBookFromDb copyBookFromDb = new CopyBookFromDb();
        RoleFromDb roleFromDb = new RoleFromDb();

        string role;

        private void btnReturnToIssue_Click(object sender, RoutedEventArgs e)
        {
            Pages.IssueBookPage issueBookPage = new Pages.IssueBookPage(_reader, _markedBooks, _selectedCopies);
            FrameClass.bookFrame.Navigate(issueBookPage);
        }

        public CatalogPage()
        {
            InitializeComponent();
            DataContext = this;
            role = roleFromDb.GetUserRole(AuthorizationWindow.currentUser.UserId);
            UpdateButtonVisibility();
        }

        public CatalogPage(Reader reader, List<Book> MarkedBooks, Dictionary<int, List<CopyBook>> SelectedCopiesBook)
        {
            InitializeComponent();
            DataContext = this;

            btnReturnToIssue.Visibility = Visibility.Visible;

            _markedBooks = MarkedBooks;
            _reader = reader;
            _selectedCopies = SelectedCopiesBook;

            role = roleFromDb.GetUserRole(AuthorizationWindow.currentUser.UserId);
            UpdateButtonVisibility();
        }

        private void UpdateButtonVisibility()
        {
            if (role == "Библиотекарь")
            {
                btnAddBook.Visibility = Visibility.Visible;
            }
        }

        private void btnAddBook_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.bookFrame.Navigate(new AddBookPage());
        }

        private void ViewAllBooks()
        {
            books = bookFromDb.LoadBook();
            foreach (var book in books)
            {
                book.AvailableCopies = copyBookFromDb.CountAvailableCopies(book.Catalog_id);
            }
            ApplyFilters();
        }

        private void ApplyFilters()
        {
            var filteredBooks = books.AsEnumerable();

            if (cB_genre.SelectedIndex > 0)
            {
                string category = cB_genre.SelectedValue.ToString();
                filteredBooks = filteredBooks.Where(b => b.Genre == category);
            }

            if (cB_publisher.SelectedIndex > 0)
            {
                string publisherName = cB_publisher.SelectedValue.ToString();
                filteredBooks = filteredBooks.Where(b => b.Publisher == publisherName);
            }

            if (cB_language.SelectedIndex > 0)
            {
                string language = cB_language.SelectedValue.ToString();
                filteredBooks = filteredBooks.Where(b => b.Language == language);
            }

            if (ChB_availability.IsChecked == true)
            {
                filteredBooks = filteredBooks.Where(b => b.AvailableCopies > 0);

                if (slMinCopies.Value > slMinCopies.Minimum)
                {
                    filteredBooks = filteredBooks.Where(b =>
                        b.AvailableCopies >= (int)slMinCopies.Value);
                }
            }

            var ageFilters = new List<int>();
            if (cB_age0.IsChecked == true) ageFilters.Add(0);
            if (cB_age12.IsChecked == true) ageFilters.Add(12);
            if (cB_age16.IsChecked == true) ageFilters.Add(16);
            if (cB_age18.IsChecked == true) ageFilters.Add(18);

            if (ageFilters.Any())
            {
                filteredBooks = filteredBooks.Where(b => ageFilters.Contains(b.Age_limit));
            }
            if (int.TryParse(tB_YearFrom.Text, out int yearFrom))
            {
                filteredBooks = filteredBooks.Where(b =>
                    b.Date_of_publication.Year >= yearFrom);
            }
            if (int.TryParse(tB_YearTo.Text, out int yearTo))
            {
                filteredBooks = filteredBooks.Where(b =>
                    b.Date_of_publication.Year <= yearTo);
            }

            if (!string.IsNullOrWhiteSpace(tB_poisk.Text) &&
                tB_poisk.Text != "Поиск по названию или фамилии автора...")
            {
                string searchLower = tB_poisk.Text.ToLower();
                filteredBooks = filteredBooks.Where(b =>
                    (b.Book_name?.ToLower().Contains(searchLower) == true) ||
                    (b.Lastname_author?.ToLower().Contains(searchLower) == true));
            }
            list_books.ItemsSource = filteredBooks.ToList();
        }

        private void ViewAllFilters()
        {
            genres = genreFromDb.LoadGenres();
            genres.Insert(0, new Genre(0, "All", ""));
            cB_genre.ItemsSource = genres;
            cB_genre.SelectedIndex = 0;

            publishers = publisherFromDb.LoadPublishers();
            publishers.Insert(0, new PublisherBook(0, "All", "", "", "", "", ""));
            cB_publisher.ItemsSource = publishers;
            cB_publisher.SelectedIndex = 0;

            languages = languageFromDb.LoadLanguages();
            languages.Insert(0, new LanguageBook(0, "", "All"));
            cB_language.ItemsSource = languages;
            cB_language.SelectedIndex = 0;

            ChB_availability.IsChecked = false;

            slMinCopies.Value = slMinCopies.Minimum;

            cB_age0.IsChecked = false;
            cB_age12.IsChecked = false;
            cB_age18.IsChecked = false;

            tB_YearFrom.Text = null;
            tB_YearTo.Text = null;
        }

        private void Catalog_page_Loaded(object sender, RoutedEventArgs e)
        {
            ViewAllBooks();
            ViewAllFilters();

        }
        private void tB_poisk_GotFocus(object sender, RoutedEventArgs e)
        {
            if (tB_poisk.Text == "Поиск по названию или фамилии автора...")
            {
                tB_poisk.Text = "";
                tB_poisk.Foreground = Brushes.Black;
            }
        }
        private void tB_poisk_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tB_poisk.Text))
            {
                tB_poisk.Text = "Поиск по названию или фамилии автора...";
                tB_poisk.Foreground = Brushes.Gray;

            }
        }
        private void btnFilters_Click(object sender, RoutedEventArgs e)
        {
            tB_poisk.Text = "Поиск по названию или фамилии автора...";
            tB_poisk.Foreground = Brushes.Gray;
            filtersPopup.IsOpen = !filtersPopup.IsOpen;
            ViewAllBooks();
        }
        private void btnYesFilt_Click(object sender, RoutedEventArgs e)
        {
            ApplyFilters();

        }
        private void btnNoFilt_Click(object sender, RoutedEventArgs e)
        {
            ViewAllBooks();
            ViewAllFilters();
            ApplyFilters();
        }
        private void tB_poisk_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (tB_poisk.Text == "Поиск по названию или фамилии автора...")
                return;
            ApplyFilters();

        }
        private void list_books_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        { }

        private void list_books_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (list_books.SelectedItem is Book selectedBook)
            {
                if (role == "Библиотекарь" && _reader != null)
                {
                    Pages.AboutBookPage aboutBookPage = new Pages.AboutBookPage(selectedBook, _reader, _markedBooks, _selectedCopies);
                    FrameClass.bookFrame.Navigate(aboutBookPage);
                }
                else
                {
                    Pages.AboutBookPage aboutBookPage = new Pages.AboutBookPage(selectedBook);
                    FrameClass.bookFrame.Navigate(aboutBookPage);
                }

            }
        }
    }
}
