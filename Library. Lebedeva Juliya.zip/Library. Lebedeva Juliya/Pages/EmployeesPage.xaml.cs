﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Classes;
using Library.Lebedeva_Juliya.Model;
using Library.Lebedeva_Juliya.Windows;

namespace Library.Lebedeva_Juliya.Pages
{
    /// <summary>
    /// Логика взаимодействия для EmployeesPage.xaml
    /// </summary>
    public partial class EmployeesPage : Page
    {
        private EmployeeFromDb employeeFromDb = new EmployeeFromDb();
        private List<Employee> employees = new List<Employee>();

        public EmployeesPage()
        {
            InitializeComponent();
        }

        private void EmployeesPage_Loaded(object sender, RoutedEventArgs e)
        {
            LoadEmployees();
        }

        private void LoadEmployees()
        {
            try
            {
                employees = employeeFromDb.LoadEmployees();
                list_employees.ItemsSource = employees;
                ApplySearchFilter();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки сотрудников: {ex.Message}");
            }
        }

        private void tB_search_GotFocus(object sender, RoutedEventArgs e)
        {
            if (tB_search.Text == "Поиск по ФИО...")
            {
                tB_search.Text = "";
                tB_search.Foreground = Brushes.Black;
            }
        }

        private void tB_search_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tB_search.Text))
            {
                tB_search.Text = "Поиск по ФИО...";
                tB_search.Foreground = Brushes.Gray;

                ApplySearchFilter();
            }
        }

        private void tB_search_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (tB_search.Text == "Поиск по ФИО...") return;
            ApplySearchFilter(tB_search.Text.Trim());
        }

        private void ApplySearchFilter(string searchText = null)
        {
            if (string.IsNullOrWhiteSpace(searchText) || searchText == "Поиск по ФИО...")
            {
                list_employees.ItemsSource = employees;
            }
            else
            {
                var filtered = employees.Where(r =>
            (r.Lastname != null && r.Lastname.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0) ||
            (r.Firstname != null && r.Firstname.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0) ||
            (r.Patronymic != null && r.Patronymic.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0)
            ).ToList();

                list_employees.ItemsSource = filtered;
            }
        }

        private void btnAddEmployee_Click(object sender, RoutedEventArgs e)
        {
            var registrationWindow = new RegistrationWindow(true);
            if (registrationWindow.ShowDialog() == true)
            {
                LoadEmployees();
            }
        }

        private void btn_employeeProfile_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is int employeeId)
            {
                int userId = employeeFromDb.GetUserIdByEmployeeId(employeeId);

                if (userId > 0)
                {
                    FrameClass.bookFrame.Navigate(new Pages.ProfilPage(userId, true));
                }
                else
                {
                    MessageBox.Show("Не удалось найти пользователя для этого сотрудника");
                }
            }
        }
    }
}
