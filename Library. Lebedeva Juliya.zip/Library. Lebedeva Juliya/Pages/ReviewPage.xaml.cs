﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Classes;
using Library.Lebedeva_Juliya.Model;

namespace Library.Lebedeva_Juliya.Pages
{
    /// <summary>
    /// Логика взаимодействия для ReviewPage.xaml
    /// </summary>
    public partial class ReviewPage : Page
    {
        ReviewFromDb reviewFromDb = new ReviewFromDb();
        public static List<Review> reviews = new List<Review>();
        private List<Review> _allReviews = new List<Review>();
        private bool _isAdmin;

        public ReviewPage(bool isAdmin = false)
        {
            InitializeComponent();
            _isAdmin = isAdmin;
            Loaded += ReviewsPage_Loaded;
        }

        private void ReviewsPage_Loaded(object sender, RoutedEventArgs e)
        {
            _allReviews = reviewFromDb.LoadReviews();
            if (_isAdmin)
            {
                foreach (var review in _allReviews)
                {
                    review.DeleteButtonVisibility = Visibility.Visible;
                }
            }
            list_Reviews.ItemsSource = _allReviews;
        }

        private void cmbRatingFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (list_Reviews == null) return;
            if (cmbRatingFilter.SelectedItem is ComboBoxItem selectedItem)
            {
                var filterType = selectedItem.Content.ToString();
                IEnumerable<Review> filtered;

                switch (filterType)
                {
                    case "1 (Плохо)":
                        filtered = _allReviews.Where(r => r.Estimation == 1);
                        break;
                    case "2 (Удовл.)":
                        filtered = _allReviews.Where(r => r.Estimation == 2);
                        break;
                    case "3 (Хорошо)":
                        filtered = _allReviews.Where(r => r.Estimation == 3);
                        break;
                    case "4 (Отлично)":
                        filtered = _allReviews.Where(r => r.Estimation == 4);
                        break;
                    case "5 (Великолепно)":
                        filtered = _allReviews.Where(r => r.Estimation == 5);
                        break;
                    default:
                        filtered = _allReviews;
                        break;
                }

                list_Reviews.ItemsSource = filtered.ToList();
            }
        }
        private void DeleteReview_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is int reviewId)
            {
                var result = MessageBox.Show("Вы уверены, что хотите удалить этот отзыв?",
                                          "Подтверждение удаления",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    if (reviewFromDb.DeleteReview(reviewId))
                    {
                        MessageBox.Show("Отзыв успешно удален");
                        _allReviews = reviewFromDb.LoadReviews();
                        if (_isAdmin)
                        {
                            foreach (var review in _allReviews)
                            {
                                review.DeleteButtonVisibility = Visibility.Visible;
                            }
                        }
                        list_Reviews.ItemsSource = _allReviews;
                    }
                    else
                    {
                        MessageBox.Show("Не удалось удалить отзыв");
                    }
                }
            }
        }
    }
}
