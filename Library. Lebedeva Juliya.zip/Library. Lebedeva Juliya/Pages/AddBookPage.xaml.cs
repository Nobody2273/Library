﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Classes;
using Library.Lebedeva_Juliya.Model;
using Microsoft.Win32;

namespace Library.Lebedeva_Juliya.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddBookPage.xaml
    /// </summary>
    public partial class AddBookPage : Page
    {
        private Book _currentBook;
        private string _imagePath = "";
        private bool _isEditMode = false;
        private int _originalBookId = 0;

        private BookFromDb _bookFromDb = new BookFromDb();
        private GenreFromDb _genreFromDb = new GenreFromDb();
        private PublisherFromDb _publisherFromDb = new PublisherFromDb();
        private LanguageFromDb _languageFromDb = new LanguageFromDb();
        private CopyBookFromDb _copyBookFromDb = new CopyBookFromDb();

        // Конструктор для добавления книги
        public AddBookPage()
        {
            InitializeComponent();
            _currentBook = new Book(0, "", 0, 0, 0, new DateTime(2000, 1, 1), "", "", "", 0, "", "", "", "", "");
            DataContext = _currentBook;
            LoadComboBoxData();
        }

        // Конструктор для редактирования существующей книги
        public AddBookPage(Book bookToEdit)
        {
            InitializeComponent();
            _currentBook = bookToEdit;
            _originalBookId = bookToEdit.Catalog_id;
            _isEditMode = true;
            DataContext = _currentBook;
            LoadComboBoxData();
            SetupEditMode();
        }

        private void SetupEditMode()
        {
            Title = "Редактирование книги";
            pageTitle.Text = "Редактирование книги";
            btnSave.Content = "Сохранить изменения";

            lblCopiesCount.Visibility = Visibility.Collapsed;
            tbCopiesCount.Visibility = Visibility.Collapsed;

            tbBookName.Text = _currentBook.Book_name;
            tbAuthorLastName.Text = _currentBook.Lastname_author;
            tbAuthorFirstName.Text = _currentBook.Firstname_author;
            tbAuthorPatronymic.Text = _currentBook.Patronymic_author;
            tbPublicationYear.Text = _currentBook.Date_of_publication.Year.ToString();
            tbPagesCount.Text = _currentBook.Number_of_pages.ToString();
            tbPrice.Text = _currentBook.Price.ToString();
            tbDescription.Text = _currentBook.Content_book;

            if (!string.IsNullOrEmpty(_currentBook.Genre))
                cbGenre.SelectedItem = ((List<Genre>)cbGenre.ItemsSource).FirstOrDefault(g => g.Category == _currentBook.Genre);

            if (!string.IsNullOrEmpty(_currentBook.Publisher))
                cbPublisher.SelectedItem = ((List<PublisherBook>)cbPublisher.ItemsSource).FirstOrDefault(p => p.PublisherName == _currentBook.Publisher);

            if (!string.IsNullOrEmpty(_currentBook.Language))
                cbLanguage.SelectedItem = ((List<LanguageBook>)cbLanguage.ItemsSource).FirstOrDefault(l => l.Language_book == _currentBook.Language);

            if (_currentBook.Age_limit > 0)
                switch (_currentBook.Age_limit)
                {
                    case 12:
                        cbAgeLimit.SelectedIndex = 1;
                        break;
                    case 16:
                        cbAgeLimit.SelectedIndex = 2;
                        break;
                    case 18:
                        cbAgeLimit.SelectedIndex = 3;
                        break;
                    default:
                        cbAgeLimit.SelectedIndex = 0;
                        break;
                }

            if (!string.IsNullOrEmpty(_currentBook.ImageWithPath))
            {
                _imagePath = _currentBook.ImageWithPath;
                imgBookCover.Source = new BitmapImage(new Uri(_imagePath));
            }
        }

        private void LoadComboBoxData()
        {
            cbGenre.ItemsSource = _genreFromDb.LoadGenres();
            cbGenre.DisplayMemberPath = "Category";

            cbPublisher.ItemsSource = _publisherFromDb.LoadPublishers();
            cbPublisher.DisplayMemberPath = "PublisherName";

            cbLanguage.ItemsSource = _languageFromDb.LoadLanguages();
            cbLanguage.DisplayMemberPath = "Language_book";
        }

        private void btnSelectImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image files (*.jpg, *.jpeg, *.png)|*.jpg;*.jpeg;*.png"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                _imagePath = openFileDialog.FileName;
                imgBookCover.Source = new BitmapImage(new Uri(_imagePath));
                _currentBook.ImageWithPath = _imagePath;
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!ValidateInputs())
                    return;

                UpdateBookFromInputs();

                if (_isEditMode)
                {
                    bool success = _bookFromDb.UpdateBook(_originalBookId, _currentBook);

                    if (success)
                    {
                        MessageBox.Show("Изменения успешно сохранены!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        NavigationService.Navigate(new AboutBookPage(_currentBook));
                    }
                    else
                    {
                        MessageBox.Show("Не удалось сохранить изменения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                else
                {
                    int bookId = _bookFromDb.AddBook(_currentBook);

                    if (bookId > 0)
                    {
                        AddCopiesForNewBook();
                        MessageBox.Show("Книга успешно добавлена!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        NavigationService.GoBack();
                    }
                    else
                    {
                        MessageBox.Show("Не удалось добавить книгу", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении книги: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(tbBookName.Text))
            {
                MessageBox.Show("Введите название книги", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (string.IsNullOrWhiteSpace(tbAuthorLastName.Text))
            {
                MessageBox.Show("Введите фамилию автора", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!int.TryParse(tbPublicationYear.Text, out int year) || year < 1800 || year > DateTime.Now.Year + 1)
            {
                MessageBox.Show("Введите корректный год издания", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!int.TryParse(tbPagesCount.Text, out int pages) || pages <= 0)
            {
                MessageBox.Show("Введите корректное количество страниц", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!int.TryParse(tbPrice.Text, out int price) || price < 0)
            {
                MessageBox.Show("Введите корректную цену", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!_isEditMode && (!int.TryParse(tbCopiesCount.Text, out int copies) || copies <= 0))
            {
                MessageBox.Show("Введите корректное количество копий", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (cbGenre.SelectedItem == null || cbPublisher.SelectedItem == null ||
                cbLanguage.SelectedItem == null || cbAgeLimit.SelectedItem == null)
            {
                MessageBox.Show("Выберите все необходимые параметры из списков", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            return true;
        }

        private void UpdateBookFromInputs()
        {
            _currentBook.Book_name = tbBookName.Text;
            _currentBook.Lastname_author = tbAuthorLastName.Text;
            _currentBook.Firstname_author = tbAuthorFirstName.Text;
            _currentBook.Patronymic_author = tbAuthorPatronymic.Text;
            _currentBook.Genre = (cbGenre.SelectedItem as Genre)?.Category;
            _currentBook.Publisher = (cbPublisher.SelectedItem as PublisherBook)?.PublisherName;
            _currentBook.Language = (cbLanguage.SelectedItem as LanguageBook)?.Language_book;
            _currentBook.Age_limit = int.Parse(((ComboBoxItem)cbAgeLimit.SelectedItem).Content.ToString().Replace("+", ""));
            _currentBook.Date_of_publication = new DateTime(int.Parse(tbPublicationYear.Text), 1, 1);
            _currentBook.Number_of_pages = int.Parse(tbPagesCount.Text);
            _currentBook.Price = int.Parse(tbPrice.Text);
            _currentBook.Content_book = tbDescription.Text;
            _currentBook.ImageWithPath = _imagePath;
        }

        private void AddCopiesForNewBook()
        {
            int copies = int.Parse(tbCopiesCount.Text);
            for (int i = 0; i < copies; i++)
            {
                var copyBook = new CopyBook(
                    copyId: 0,
                    deliveryDate: DateTime.Now,
                    condition: "Новый",
                    bookName: _currentBook.Book_name,
                    status: "Доступен")
                {
                    MarkedForIssue = false
                };

                _copyBookFromDb.AddCopyBook(copyBook);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
