﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Classes;
using Library.Lebedeva_Juliya.Model;
using Library.Lebedeva_Juliya.Windows;

namespace Library.Lebedeva_Juliya.Pages
{
    /// <summary>
    /// Логика взаимодействия для ReaderCardPage.xaml
    /// </summary>
    public partial class ReaderCardPage : Page
    {
        public List<Book> books { get; set; } = new List<Book>();
        BookFromDb bookFromDb = new BookFromDb();

        public List<CopyBook> copyBooks { get; set; } = new List<CopyBook>();
        CopyBookFromDb copyBookFromDb = new CopyBookFromDb();

        public List<ReaderCard> readerCards { get; set; } = new List<ReaderCard>();
        ReaderCardFromDb readerCardFromDb = new ReaderCardFromDb();

        ReaderFromDb readerFromDb = new ReaderFromDb();
        ExportDocument exportDocument = new ExportDocument();

        RoleFromDb roleFromDb = new RoleFromDb();

        ReviewFromDb reviewFromDb = new ReviewFromDb();

        Reader currentReader;
        int currentReaderId;
        private string _currentRole;

        private IEnumerable<dynamic> _allReaderCards;
        public ReaderCardPage()
        {
            InitializeComponent();
        }
        public ReaderCardPage(Reader reader)
        {
            InitializeComponent();

            currentReader = reader;
        }
        private void UpdateNavigationForRole(string role)
        {
            switch (role)
            {
                case "Библиотекарь":
                    currentReaderId = currentReader.ReaderId;
                    break;

                case "Читатель":
                    currentReaderId = readerFromDb.GetReaderId(AuthorizationWindow.currentUser.UserId);
                    break;
            }
        }
        private void ReaderCard_page_Loaded(object sender, RoutedEventArgs e)
        {
            _currentRole = roleFromDb.GetUserRole(AuthorizationWindow.currentUser.UserId);
            UpdateNavigationForRole(_currentRole);
            ViewCard();

        }
        public void ViewCard()
        {
            books = bookFromDb.LoadBook();
            copyBooks = copyBookFromDb.LoadCopyBooks();
            readerCards = readerCardFromDb.LoadReaderCards();

            _allReaderCards = (from card in readerCards
                               join copy in copyBooks on card.Copy_id equals copy.CopyId
                               join book in books on copy.BookName equals book.Book_name
                               where card.Reader_id == currentReaderId
                               let isOverdue = !card.Is_returned && DateTime.Now > card.Opening_date.AddDays(card.Return_period)
                               let overdueDays = isOverdue ? (DateTime.Now - card.Opening_date.AddDays(card.Return_period)).Days : 0
                               let sortPriority = card.Is_returned ? 3 :
                                                 card.Extension_book ? 1 :
                                                 isOverdue ? 0 : 2
                               orderby sortPriority, card.Opening_date descending
                               select new
                               {
                                   Card = card,
                                   Copy = copy,
                                   Book = book,
                                   IsOverdue = isOverdue,
                                   OverdueDays = overdueDays,
                                   UserRole = _currentRole,
                                   HasReview = card.ReviewId != null
                               }).ToList();

            list_ReaderCards.ItemsSource = _allReaderCards;

            if (!_allReaderCards.Any())
            {
                MessageBox.Show("В вашем формуляре пока нет книг. Ознакомьтесь с каталогом и приходите к нам в библиотеку",
                              "Информация",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void btn_extension_Click(object sender, RoutedEventArgs e)
        {
            if (((Button)sender).Tag is int cardId)
            {
                try
                {
                    var cardToExtend = readerCards.FirstOrDefault(c => c.CardOfReader_id == cardId);

                    if (cardToExtend != null)
                    {
                        cardToExtend.Return_period = 45;
                        cardToExtend.Extension_book = true;
                        cardToExtend.Return_date = cardToExtend.Opening_date.AddDays(cardToExtend.Return_period);

                        if (readerCardFromDb.UpdateReaderCard(cardToExtend))
                        {
                            MessageBox.Show("Срок возврата продлен на 15 дней", "Успех",
                                         MessageBoxButton.OK, MessageBoxImage.Information);
                            ViewCard();
                        }
                        else
                        {
                            MessageBox.Show("Не удалось обновить срок возврата", "Ошибка",
                                         MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                                 MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void cmbFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (list_ReaderCards == null) return;
            if (cmbFilter.SelectedItem is ComboBoxItem selectedItem)
            {
                var filterType = selectedItem.Content.ToString();
                IEnumerable<dynamic> filtered;

                switch (filterType)
                {

                    case "Активные":
                        filtered = _allReaderCards.Where(c => !c.Card.Is_returned && !c.IsOverdue && !c.Card.Extension_book);
                        break;
                    case "Просроченные":
                        filtered = _allReaderCards.Where(c => c.IsOverdue);
                        break;
                    case "Продленные":
                        filtered = _allReaderCards.Where(c => c.Card.Extension_book && !c.Card.Is_returned);
                        break;
                    case "Возвращенные":
                        filtered = _allReaderCards.Where(c => c.Card.Is_returned);
                        break;
                    default:
                        filtered = _allReaderCards;
                        break;
                }

                list_ReaderCards.ItemsSource = filtered.ToList();
            }
        }

        private void btn_documentCard_Click(object sender, RoutedEventArgs e)
        {
            if (_allReaderCards == null || !_allReaderCards.Any())
            {
                MessageBox.Show("Нет данных для экспорта",
                              "Информация",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
                return;
            }

            exportDocument.ExportReaderCardsToExcel(_allReaderCards);
        }

        private void btn_return_Click(object sender, RoutedEventArgs e)
        {

            if (((Button)sender).Tag is int cardId)
            {
                try
                {
                    var card = readerCards.FirstOrDefault(c => c.CardOfReader_id == cardId);
                    var returnWindow = new ReturnWindow(cardId, card.Copy_id);

                    if (returnWindow.ShowDialog() != true || !returnWindow.IsReturnCompleted)
                    {
                        return;
                    }

                    bool updateSuccess = true;

                    if (!string.IsNullOrEmpty(returnWindow.SelectedCondition) &&
                        returnWindow.SelectedCondition != returnWindow.OriginalCondition)
                    {
                        var copyBookFromDb = new CopyBookFromDb();
                        updateSuccess = copyBookFromDb.UpdateCopyBookCondition(card.Copy_id, returnWindow.SelectedCondition);

                        if (!updateSuccess)
                        {
                            MessageBox.Show("Не удалось обновить состояние экземпляра книги", "Ошибка",
                                         MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }

                    var returnSuccess = readerCardFromDb.ReturnBook(cardId);

                    if (returnSuccess)
                    {
                        MessageBox.Show("Книга успешно возвращена", "Успех",
                                     MessageBoxButton.OK, MessageBoxImage.Information);
                        ViewCard();
                    }
                    else
                    {
                        MessageBox.Show("Не удалось оформить возврат книги", "Ошибка",
                                     MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при возврате книги: {ex.Message}", "Ошибка",
                                 MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        private void btn_review_Click(object sender, RoutedEventArgs e)
        {

            var button = sender as Button;
            if (button == null) return;

            int cardId = (int)button.Tag;

            var reviewWindow = new ReviewWindow(cardId);
            if (reviewWindow.ShowDialog() == true)
            {
                ViewCard();
                MessageBox.Show("Отзыв успешно добавлен!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
