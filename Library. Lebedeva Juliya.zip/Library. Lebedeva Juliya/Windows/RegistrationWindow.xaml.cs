﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Model;
using Library.Lebedeva_Juliya.Classes;
using System.ComponentModel;

namespace Library.Lebedeva_Juliya.Windows
{
    /// <summary>
    /// Логика взаимодействия для RegistrationWindow.xaml
    /// </summary>
    public partial class RegistrationWindow : Window
    {
        private readonly UserFromDb _userFromDb = new UserFromDb();
        private readonly ReaderFromDb _readerFromDb = new ReaderFromDb();
        private readonly EmployeeFromDb _employeeFromDb = new EmployeeFromDb();
        private readonly PostFromDb _postFromDb = new PostFromDb();

        private bool _isEmployeeRegistration;

        public event PropertyChangedEventHandler PropertyChanged;

        public RegistrationWindow(bool isEmployeeRegistration = false)
        {
            InitializeComponent();
            _isEmployeeRegistration = isEmployeeRegistration;
            DataContext = this;

            if (_isEmployeeRegistration)
            {
                LoadPosts();
                tB_email.Text = "rus-44.meja@yandex.ru";
            }
        }

        private void LoadPosts()
        {
            try
            {
                var posts = _postFromDb.GetAllPosts();
                cbPost.ItemsSource = posts;
                if (posts.Any())
                {
                    cbPost.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке должностей: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void bt_passGen_Click(object sender, RoutedEventArgs e)
        {
            string upperCase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string lowerCase = "abcdefghijklmnopqrstuvwxyz";
            string digits = "0123456789";
            string specialCharacters = "!@#$%^&*()";

            Random random = new Random();
            StringBuilder password = new StringBuilder();
            password.Append(upperCase[random.Next(upperCase.Length)]);
            password.Append(lowerCase[random.Next(lowerCase.Length)]);
            password.Append(digits[random.Next(digits.Length)]);
            password.Append(specialCharacters[random.Next(specialCharacters.Length)]);
            string allCharacters = upperCase + lowerCase + digits + specialCharacters;
            for (int i = 4; i < 8; i++)
            {
                password.Append(allCharacters[random.Next(allCharacters.Length)]);
            }
            string finalPassword = new string(password.ToString().OrderBy(c => random.Next()).ToArray());

            if (tB_passwordVisible.Visibility == Visibility.Visible)
            {
                tB_passwordVisible.Text = finalPassword;
            }
            else
            {
                tB_password.Password = finalPassword;
            }
        }

        private void ValidatePasswords()
        {
            bool passwordsMatch = tB_password.Password == tB_checkPass.Password;
            bool isPasswordEmpty = string.IsNullOrEmpty(tB_password.Password);
            bool isConfirmEmpty = string.IsNullOrEmpty(tB_checkPass.Password);

            if (!passwordsMatch && !isPasswordEmpty && !isConfirmEmpty)
            {
                tB_checkPass.BorderBrush = Brushes.Red;
                tB_checkPass.BorderThickness = new Thickness(0, 0, 0, 2);

                tB_checkPassVisible.BorderBrush = Brushes.Red;
                tB_checkPassVisible.BorderThickness = new Thickness(0, 0, 0, 2);

                passwordErrorText.Visibility = Visibility.Visible;
            }
            else
            {
                tB_checkPass.ClearValue(PasswordBox.BorderBrushProperty);
                tB_checkPass.ClearValue(PasswordBox.BorderThicknessProperty);

                tB_checkPassVisible.ClearValue(TextBox.BorderBrushProperty);
                tB_checkPassVisible.ClearValue(TextBox.BorderThicknessProperty);

                passwordErrorText.Visibility = Visibility.Collapsed;
            }
        }

        private void SendEmail(string userEmail, string userLogin, string userPassword, string userName)
        {
            try
            {
                SmtpClient smtpClient = new SmtpClient("smtp.yandex.ru", 587)
                {
                    Credentials = new NetworkCredential("rus-44.meja@yandex.ru", "bjsihmgobhrnudzr"),
                    EnableSsl = true
                };

                MailMessage mailMessage = new MailMessage
                {
                    From = new MailAddress("rus-44.meja@yandex.ru", "Бесконечная глава"),
                    Subject = _isEmployeeRegistration ?
                        "Данные для входа в систему (сотрудник)" :
                        "Регистрация в приложении 'Бесконечная глава'",
                    Body = $"{userName}, {(_isEmployeeRegistration ? "ваши данные для входа в систему:" : "спасибо за регистрацию!")}\n" +
                           $"Ваш логин: {userLogin}\nВаш пароль: {userPassword}"
                };

                mailMessage.To.Add(userEmail);

                smtpClient.Send(mailMessage);
                MessageBox.Show("Письмо с данными отправлено на указанную почту");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при отправке письма: {ex.Message}", "Ошибка", MessageBoxButton.OK);
            }
        }

        private void bt_registration_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tB_name.Text) ||
                string.IsNullOrWhiteSpace(tB_lastName.Text) ||
                string.IsNullOrWhiteSpace(tB_login.Text) ||
                string.IsNullOrWhiteSpace(tB_password.Password) ||
                string.IsNullOrWhiteSpace(tB_checkPass.Password) ||
                string.IsNullOrWhiteSpace(tB_email.Text))
            {
                MessageBox.Show("Необходимо заполнить все обязательные поля");
                return;
            }

            if (_isEmployeeRegistration && cbPost.SelectedItem == null)
            {
                MessageBox.Show("Необходимо выбрать должность");
                return;
            }
            if (!_isEmployeeRegistration)
            {
                if (!_userFromDb.IsEmailUnique(tB_email.Text))
                {
                    MessageBox.Show("Пользователь с таким email уже существует");
                    tB_email.BorderBrush = Brushes.Red;
                    tB_email.BorderThickness = new Thickness(0, 0, 0, 2);
                    return;
                }
            }

            if (!_userFromDb.IsEmailValid(tB_email.Text))
            {
                MessageBox.Show("Указан некорректный email адрес");
                tB_email.BorderBrush = Brushes.Red;
                tB_email.BorderThickness = new Thickness(0, 0, 0, 2);
                return;
            }

            if (tB_password.Password != tB_checkPass.Password)
            {
                ValidatePasswords();
                MessageBox.Show("Пароли не совпадают");
                return;
            }

            bool passwordValid = _userFromDb.CheckPassword(tB_password.Password, tB_checkPass.Password);
            if (!passwordValid) return;

            if (_userFromDb.CheckUser(tB_login.Text))
            {
                MessageBox.Show("Пользователь с таким логином уже существует");
                return;
            }

            try
            {
                int userId = _userFromDb.UserAdd(
                    tB_login.Text,
                    tB_password.Password,
                    tB_email.Text,
                    "",
                    _isEmployeeRegistration ? 2 : 1
                );

                if (_isEmployeeRegistration)
                {
                    var selectedPost = (Post)cbPost.SelectedItem;
                    _employeeFromDb.AddEmployee(
                        tB_name.Text,
                        tB_lastName.Text,
                        tB_patronymic.Text,
                        selectedPost.PostId,
                        userId
                    );

                    MessageBox.Show("Сотрудник успешно добавлен");
                }
                else
                {
                    _readerFromDb.RegistrationReader(userId, tB_name.Text, tB_lastName.Text);
                }

                SendEmail(tB_email.Text, tB_login.Text, tB_password.Password, tB_name.Text);

                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при регистрации: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void bt_togglePassword_Click(object sender, RoutedEventArgs e)
        {
            if (tB_passwordVisible.Visibility == Visibility.Visible)
            {
                tB_passwordVisible.Visibility = Visibility.Collapsed;
                tB_password.Visibility = Visibility.Visible;
                tB_password.Password = tB_passwordVisible.Text;
            }
            else
            {
                tB_passwordVisible.Text = tB_password.Password;
                tB_passwordVisible.Visibility = Visibility.Visible;
                tB_password.Visibility = Visibility.Collapsed;
            }
        }

        private void bt_toggleCheckPass_Click(object sender, RoutedEventArgs e)
        {
            if (tB_checkPassVisible.Visibility == Visibility.Visible)
            {
                tB_checkPassVisible.Visibility = Visibility.Collapsed;
                tB_checkPass.Visibility = Visibility.Visible;
                tB_checkPass.Password = tB_checkPassVisible.Text;
            }
            else
            {
                tB_checkPassVisible.Text = tB_checkPass.Password;
                tB_checkPassVisible.Visibility = Visibility.Visible;
                tB_checkPass.Visibility = Visibility.Collapsed;
            }
        }

        private void tB_password_PasswordChanged(object sender, RoutedEventArgs e)
        {
            ValidatePasswords();

            if (tB_passwordVisible.Visibility == Visibility.Visible)
            {
                tB_passwordVisible.Text = tB_password.Password;
            }
        }

        private void tB_checkPass_PasswordChanged(object sender, RoutedEventArgs e)
        {
            ValidatePasswords();

            if (tB_checkPassVisible.Visibility == Visibility.Visible)
            {
                tB_checkPassVisible.Text = tB_checkPass.Password;
            }
        }

        private void tB_passwordVisible_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (tB_passwordVisible.Visibility == Visibility.Visible)
            {
                tB_password.Password = tB_passwordVisible.Text;
                ValidatePasswords();
            }
        }

        private void tB_checkPassVisible_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (tB_checkPassVisible.Visibility == Visibility.Visible)
            {
                tB_checkPass.Password = tB_checkPassVisible.Text;
                ValidatePasswords();
            }
        }
    }
}
