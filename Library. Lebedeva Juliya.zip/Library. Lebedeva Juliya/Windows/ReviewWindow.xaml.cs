﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Model;

namespace Library.Lebedeva_Juliya.Windows
{
    /// <summary>
    /// Логика взаимодействия для ReviewWindow.xaml
    /// </summary>
    public partial class ReviewWindow : Window
    {
        public string ReviewText { get; private set; }
        public int Estimation { get; private set; }
        private readonly int _cardId;

        public ReviewWindow(int cardId)
        {
            InitializeComponent();
            _cardId = cardId;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbReviewText.Text))
            {
                MessageBox.Show("Пожалуйста, введите текст отзыва",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ReviewText = tbReviewText.Text;
            Estimation = cmbEstimation.SelectedIndex + 1;

            var reviewDb = new ReviewFromDb();

            int reviewId = reviewDb.InsertReview(ReviewText, Estimation);

            if (reviewId == -1)
            {
                this.DialogResult = false;
            }
            else
            {
                var cardDb = new ReaderCardFromDb();
                bool success = cardDb.UpdateCardWithReview(_cardId, reviewId);

                this.DialogResult = success;
            }

            this.Close();
        }
    }
}
