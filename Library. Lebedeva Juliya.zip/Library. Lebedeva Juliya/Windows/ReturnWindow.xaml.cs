﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Model;

namespace Library.Lebedeva_Juliya.Windows
{
    /// <summary>
    /// Логика взаимодействия для ReturnWindow.xaml
    /// </summary>
    public partial class ReturnWindow : Window
    {
        private int _copyId;

        public bool IsReturnCompleted { get; private set; }
        public string SelectedCondition { get; private set; }
        public string Notes { get; private set; }
        public string OriginalCondition { get; private set; }

        public ReturnWindow(int cardId, int copyId)
        {
            InitializeComponent();
            _copyId = copyId;

            var copyBookFromDb = new CopyBookFromDb();
            OriginalCondition = copyBookFromDb.GetCopyBookCondition(_copyId);
            txtCondition.Text = OriginalCondition;
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            btnEdit.Visibility = Visibility.Collapsed;
            btnSave.Visibility = Visibility.Visible;
            btnCancel.Visibility = Visibility.Visible;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            SelectedCondition = txtCondition.Text;
            EditVisible();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            txtCondition.Text = OriginalCondition;
            EditVisible();
        }

        private void EditVisible()
        {
            btnEdit.Visibility = Visibility.Visible;
            btnSave.Visibility = Visibility.Collapsed;
            btnCancel.Visibility = Visibility.Collapsed;
        }

        private void btnComplete_Click(object sender, RoutedEventArgs e)
        {
            if (btnEdit.Visibility != Visibility.Visible)
            {
                MessageBox.Show("Сначала завершите редактирование", "Ошибка",
                             MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtCondition.Text))
            {
                MessageBox.Show("Укажите состояние экземпляра", "Ошибка",
                             MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            Notes = txtNote.Text;
            SelectedCondition = txtCondition.Text;

            IsReturnCompleted = true;
            DialogResult = true;
            Close();
        }
    }
}
