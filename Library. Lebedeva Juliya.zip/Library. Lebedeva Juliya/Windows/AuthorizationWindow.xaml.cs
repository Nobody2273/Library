﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Classes;
using Library.Lebedeva_Juliya.Model;

namespace Library.Lebedeva_Juliya.Windows
{
    /// <summary>
    /// Логика взаимодействия для AuthorizationWindow.xaml
    /// </summary>
    public partial class AuthorizationWindow : Window
    {
        UserFromDb userFromDb = new UserFromDb();
        private int failedAttempts = 0;
        public static User currentUser { get; set; } = null;
        public AuthorizationWindow()
        {
            InitializeComponent();
        }
        private void bt_ent_Click(object sender, RoutedEventArgs e)
        {
            if (!(tB_login.Text != "" && tB_password.Password != ""))
            {
                MessageBox.Show("Введите данные");
                return;
            }
            else
            {
                currentUser = userFromDb.GetUser(tB_login.Text, tB_password.Password);
                if (currentUser != null)
                {
                    if (failedAttempts > 0)
                    {
                        CaptchaWindow captchaForm = new CaptchaWindow(this);
                        captchaForm.Show();
                    }
                    else
                    {
                        MainWindow mainForm = new MainWindow();
                        mainForm.Show();
                        this.Hide();
                    }
                }
                else
                {
                    failedAttempts += 1;
                    return;
                }
            }
        }
        private void bt_reg_Click(object sender, RoutedEventArgs e)
        {
            var registrationWindow = new RegistrationWindow();
            if (registrationWindow.ShowDialog() == true)
            { }
        }

        private void bt_togglePassword_Click(object sender, RoutedEventArgs e)
        {
            if (tB_password.Visibility == Visibility.Visible)
            {
                tB_passwordVisible.Text = tB_password.Password;
                tB_passwordVisible.Visibility = Visibility.Visible;
                tB_password.Visibility = Visibility.Collapsed;
                ((Button)sender).ToolTip = "Скрыть пароль";
            }
            else
            {
                tB_password.Password = tB_passwordVisible.Text;
                tB_password.Visibility = Visibility.Visible;
                tB_passwordVisible.Visibility = Visibility.Collapsed;
                ((Button)sender).ToolTip = "Показать пароль";
            }
        }
        private void tB_password_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (tB_passwordVisible.Visibility == Visibility.Visible)
            {
                tB_passwordVisible.Text = tB_password.Password;
            }
        }

        private void tB_passwordVisible_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (tB_passwordVisible.Visibility == Visibility.Visible)
            {
                tB_password.Password = tB_passwordVisible.Text;
            }
        }
    }
}
