﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Library.Lebedeva_Juliya.Classes;
using Library.Lebedeva_Juliya.Model;

namespace Library.Lebedeva_Juliya.Windows
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        RoleFromDb roleFromDb = new RoleFromDb();
        public string role;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            FrameClass.bookFrame = bookFrame;
            FrameClass.bookFrame.Navigate(new Pages.CatalogPage());
            SetActiveButton(btnCatalog);

            role = roleFromDb.GetUserRole(AuthorizationWindow.currentUser.UserId);
            UpdateNavigationForRole(role);
        }
        private void UpdateNavigationForRole(string role)
        {
            btnCatalog.Visibility = Visibility.Visible;
            btn_review.Visibility = Visibility.Visible;

            switch (role)
            {
                case "Библиотекарь":
                    btn_readers.Visibility = Visibility.Visible;
                    break;

                case "Читатель":
                    btn_readerShelf.Visibility = Visibility.Visible;
                    btn_readerCard.Visibility = Visibility.Visible;
                    break;
                case "Администратор":
                    btn_employee.Visibility = Visibility.Visible;
                    break;
            }
        }

        private void btnCatalog_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.bookFrame.Navigate(new Pages.CatalogPage());
            SetActiveButton(btnCatalog);
        }

        private void btn_readerShelf_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.bookFrame.Navigate(new Pages.ReaderShelfPage());
            SetActiveButton(btn_readerShelf);
        }

        private void SetActiveButton(Button activeButton)
        {
            var navButtons = new[] { btnCatalog, btn_readerShelf, btn_employee, btn_exitProfil,
                                    btn_readerCard, btn_review };

            foreach (var button in navButtons)
            {
                if (button == activeButton)
                {
                    button.Style = (Style)FindResource("ActiveNavigationButtonStyle");
                }
                else
                {
                    button.Style = (Style)FindResource("NavigationButtonStyle");
                }
            }
        }

        private void btn_readerCard_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.bookFrame.Navigate(new Pages.ReaderCardPage());
            SetActiveButton(btn_readerCard);
        }

        private void btn_exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btn_readers_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.bookFrame.Navigate(new Pages.ReadersPage());
            SetActiveButton(btn_readers);
        }
        private void btn_exitProfil_Click(object sender, RoutedEventArgs e)
        {
            AuthorizationWindow authorizationWindow = new AuthorizationWindow();
            authorizationWindow.Show();
            this.Hide();
        }

        private void btn_review_Click(object sender, RoutedEventArgs e)
        {
            if (role == "Администратор")
                FrameClass.bookFrame.Navigate(new Pages.ReviewPage(true));
            else
                FrameClass.bookFrame.Navigate(new Pages.ReviewPage());
            SetActiveButton(btn_readers);
        }

        private void btn_profil_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.bookFrame.Navigate(new Pages.ProfilPage(AuthorizationWindow.currentUser.UserId));
            SetActiveButton(btn_profil);
        }

        private void btn_employee_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.bookFrame.Navigate(new Pages.EmployeesPage());
            SetActiveButton(btn_employee);
        }
    }
}
