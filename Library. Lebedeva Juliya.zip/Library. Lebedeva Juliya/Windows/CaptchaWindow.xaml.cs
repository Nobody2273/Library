﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;
using Color = System.Drawing.Color;
using Brushes = System.Drawing.Brushes;
using Point = System.Drawing.Point;
using System.Drawing;

namespace Library.Lebedeva_Juliya.Windows
{
    /// <summary>
    /// Логика взаимодействия для CaptchaWindow.xaml
    /// </summary>
    public partial class CaptchaWindow : Window
    {
        private string text = String.Empty;
        private AuthorizationWindow authorizationForm;
        public CaptchaWindow(AuthorizationWindow authorizationForm)
        {
            InitializeComponent();
            this.authorizationForm = authorizationForm;
        }
        private void Captcha()
        {
            pB_captcha.Source = CreateImage(Convert.ToInt32(pB_captcha.Width), Convert.ToInt32(pB_captcha.Height));
        }

        private BitmapImage CreateImage(int Width, int Height)
        {
            Random rnd = new Random();
            Bitmap result = new Bitmap(Width, Height);

            int Xpos = rnd.Next(0, Width - 70);
            int Ypos = rnd.Next(15, Height - 12);

            System.Drawing.Brush[] colors = { Brushes.Yellow, Brushes.Red, Brushes.Orange, Brushes.Green };

            Graphics g = Graphics.FromImage((System.Drawing.Image)result);

            g.Clear(Color.Gray);

            string ALF = "1234567890QWERTYUIOPASDFGHJKLZXCVBNM";
            text = "";
            for (int i = 0; i < 4; ++i)
                text += ALF[rnd.Next(ALF.Length)];

            g.DrawString(text, new Font("Arial", 20), colors[rnd.Next(colors.Length)], new PointF(Xpos, Ypos));
            g.DrawLine(Pens.Green, new Point(0, 0), new Point(Width - 1, Height - 1));
            g.DrawLine(Pens.Red, new Point(0, Height - 5), new Point(Width - 15, 0));

            for (int i = 0; i < Width; ++i)
                for (int j = 0; j < Height; ++j)
                    if (rnd.Next() % 25 == 0)
                        result.SetPixel(i, j, Color.White);

            BitmapImage bitmapImage = new BitmapImage();
            using (MemoryStream memory = new MemoryStream())
            {
                result.Save(memory, System.Drawing.Imaging.ImageFormat.Png);
                memory.Position = 0;
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = memory;
                bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                bitmapImage.EndInit();
            }
            result.Dispose();

            return bitmapImage;
        }

        private void bt_update_Click(object sender, RoutedEventArgs e)
        {
            Captcha();
        }
        private void bt_ok_Click(object sender, RoutedEventArgs e)
        {
            if (tB_captcha.Text == this.text)
            {
                MessageBox.Show("Капча введена верно");
                MainWindow mainForm = new MainWindow();
                mainForm.Show();
                this.authorizationForm.Hide();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Ошибка при заполнении капчи");
                Captcha();
            }
        }
        private void CaptchaWindow_Loaded(object sender, RoutedEventArgs e)
        {
            Captcha();
        }
    }
}
