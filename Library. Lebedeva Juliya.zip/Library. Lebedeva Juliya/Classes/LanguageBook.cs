﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Lebedeva_Juliya.Classes
{
    public class LanguageBook
    {
        public int LanguageId { get; set; }
        public string LanguageCode { get; set; }
        public string Language_book { get; set; }

        public LanguageBook(int languageId, string languageCode, string language_book)
        {
            LanguageId = languageId;
            LanguageCode = languageCode;
            Language_book = language_book;
        }
    }
}
