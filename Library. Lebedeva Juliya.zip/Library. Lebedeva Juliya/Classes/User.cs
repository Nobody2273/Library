﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Lebedeva_Juliya.Classes
{
    public class User
    {
        public int UserId { get; set; }
        public string Login { get; set; }
        public string PasswordUser { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public int RoleId { get; set; }
        public bool IsActive { get; set; }

        public User(int userId, string login, string passwordUser,
                    string email, string phone, int roleId, bool isActive)
        {
            UserId = userId;
            Login = login;
            PasswordUser = passwordUser;
            Email = email;
            Phone = phone;
            RoleId = roleId;
            IsActive = isActive;
        }
    }
}
