﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using Npgsql.TypeMapping;

namespace Library.Lebedeva_Juliya.Classes
{
    public class Book : INotifyPropertyChanged
    {
        public int Catalog_id { get; set; }
        public string Book_name { get; set; }
        public int Number_of_copies { get; set; }
        public int Number_of_pages { get; set; }
        public int Price { get; set; }
        public DateTime Date_of_publication { get; set; }
        public string Content_book { get; set; }

        string image;
        public string Language { get; set; }
        public string Publisher { get; set; }
        public int Age_limit { get; set; }
        public string Firstname_author { get; set; }
        public string Lastname_author { get; set; }
        public string Patronymic_author { get; set; }
        public string Genre { get; set; }
        public int AvailableCopies { get; set; }

        public bool MarkedForVisit { get; set; }
        public string SelectedCopyDescription { get; set; }

        public string ImageWithPath
        {
            get
            {
                string path = Path.Combine(@"C:\Users\Juliya\source\repos\Library. Lebedeva Juliya\Images\", image);
                if (!String.IsNullOrEmpty(image) && File.Exists(path))
                { return path; }
                else
                { return @"C:\Users\Juliya\source\repos\Library. Lebedeva Juliya\Images\book.png"; }
            }
            set
            {
                image = value;
                OnPropertyChanged("ImageWithPath");
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
        public Book(int catalogId, string bookName, int numberOfCopies, int numberOfPages,
               int price, DateTime dateOfPublication, string contentBook,
               string language, string publisher, int ageLimit,
               string firstnameAuthor, string lastnameAuthor, string patronymicAuthor,
               string genre, string image)
        {
            Catalog_id = catalogId;
            Book_name = bookName;
            Number_of_copies = numberOfCopies;
            Number_of_pages = numberOfPages;
            Price = price;
            Date_of_publication = dateOfPublication;
            Content_book = contentBook;
            Language = language;
            Publisher = publisher;
            Age_limit = ageLimit;
            Firstname_author = firstnameAuthor;
            Lastname_author = lastnameAuthor;
            Patronymic_author = patronymicAuthor;
            Genre = genre;
            this.image = image;
        }
    }
}
