﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Lebedeva_Juliya.Classes
{
    public class CopyBook
    {
        public int CopyId { get; set; }
        public DateTime DeliveryDate { get; set; }
        public string Condition { get; set; }
        public string BookName { get; set; }
        public string Status { get; set; }
        public int CopyNumber { get; set; }
        public bool MarkedForIssue { get; set; }

        public CopyBook(int copyId, DateTime deliveryDate, string condition, string bookName, string status)
        {
            CopyId = copyId;
            DeliveryDate = deliveryDate;
            Condition = condition;
            BookName = bookName;
            Status = status;
        }
    }
}
