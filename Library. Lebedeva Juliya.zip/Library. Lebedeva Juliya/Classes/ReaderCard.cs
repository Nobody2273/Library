﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Lebedeva_Juliya.Classes
{
    public class ReaderCard
    {
        public int CardOfReader_id { get; set; }
        public DateTime Opening_date { get; set; }
        public int Return_period { get; set; }
        public DateTime Return_date { get; set; }
        public bool Extension_book { get; set; }
        public int Copy_id { get; set; }
        public int Reader_id { get; set; }
        public int? PenaltyId { get; set; }
        public int? ReviewId { get; set; }
        public bool Is_returned { get; set; }

        public ReaderCard(int cardOfReader_id, DateTime opening_date, int return_period, DateTime return_date, bool extension_book,
            int copy_id, int reader_id, int? penaltyId, int? reviewId, bool is_returned)
        {
            CardOfReader_id = cardOfReader_id;
            Opening_date = opening_date;
            Return_period = return_period;
            Return_date = return_date;
            Extension_book = extension_book;
            Copy_id = copy_id;
            Reader_id = reader_id;
            PenaltyId = penaltyId;
            ReviewId = reviewId;
            Is_returned = is_returned;
        }
    }
}
