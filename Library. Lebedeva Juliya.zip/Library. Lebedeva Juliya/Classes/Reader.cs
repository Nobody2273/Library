﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Lebedeva_Juliya.Classes
{
    public class Reader
    {
        public int ReaderId { get; set; }
        public int UserId { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Patronymic { get; set; }
        public DateTime? BirthDate { get; set; }
        public string Address { get; set; }
        public DateTime RegistrationDate { get; set; }
        public int UnreturnedBooksCount { get; set; }

        public Reader(int readerId, int userId, string firstname, string lastname,
                     string patronymic, DateTime? birthDate, string address,
                     DateTime registrationDate)
        {
            ReaderId = readerId;
            UserId = userId;
            Firstname = firstname;
            Lastname = lastname;
            Patronymic = patronymic;
            BirthDate = birthDate;
            Address = address;
            RegistrationDate = registrationDate;
        }
    }
}
