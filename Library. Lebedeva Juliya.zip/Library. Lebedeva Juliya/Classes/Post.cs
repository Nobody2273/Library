﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Lebedeva_Juliya.Classes
{
    public class Post
    {
        public int PostId { get; set; }
        public string PostName { get; set; }
        public int Salary { get; set; }
        public string Duty { get; set; }

        public Post(int postId, string post, int salary, string duty)
        {
            PostId = postId;
            PostName = post;
            Salary = salary;
            Duty = duty;
        }
    }
}
