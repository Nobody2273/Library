﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Lebedeva_Juliya.Classes
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Patronymic { get; set; }
        public string Post { get; set; }
        public decimal Salary { get; set; }
        public DateTime HireDate { get; set; }

        public Employee(int employeeId, string firstname, string lastname, string patronymic, string post, decimal salary, DateTime hireDate)
        {
            EmployeeId = employeeId;
            Firstname = firstname;
            Lastname = lastname;
            Patronymic = patronymic;
            Post = post;
            Salary = salary;
            HireDate = hireDate;
        }
    }
}
