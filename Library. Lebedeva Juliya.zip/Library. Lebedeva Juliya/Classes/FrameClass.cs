﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Library.Lebedeva_Juliya.Classes
{
    internal class FrameClass
    {
        public static Frame bookFrame;
    }
}
