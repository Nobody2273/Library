﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Library.Lebedeva_Juliya.Classes
{
    public class Review
    {
        public int ReviewId { get; set; }
        public string ReviewText { get; set; }
        public int Estimation { get; set; }
        public DateTime ReviewDate { get; set; }
        public string BookName { get; set; }
        public string AuthorName { get; set; }
        public string ReaderName { get; set; }

        public Visibility DeleteButtonVisibility { get; set; } = Visibility.Collapsed;

        public Review(int reviewId, string reviewText, int estimation, DateTime reviewDate, string bookName, string authorName, string readerName)
        {
            ReviewId = reviewId;
            ReviewText = reviewText;
            Estimation = estimation;
            ReviewDate = reviewDate;
            BookName = bookName;
            AuthorName = authorName;
            ReaderName = readerName;
        }
    }
}
