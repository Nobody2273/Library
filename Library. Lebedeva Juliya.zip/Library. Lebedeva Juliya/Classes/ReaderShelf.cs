﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Lebedeva_Juliya.Classes
{
    public class ReaderShelf
    {
        public int Reader_id { get; set; }
        public int Catalog_id { get; set; }
        public bool MarkedForVisit { get; set; }
        public DateTime Added_date { get; set; }

        public ReaderShelf(int reader_id, int catalog_id, bool markedForVisit, DateTime added_date)
        {
            Reader_id = reader_id;
            Catalog_id = catalog_id;
            MarkedForVisit = markedForVisit;
            Added_date = added_date;
        }
    }
}
