﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Lebedeva_Juliya.Classes
{
    public class PublisherBook
    {
        public int PublisherId { get; set; }
        public string PublisherName { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Website { get; set; }
        public string ContactPerson { get; set; }

        public PublisherBook(int publisherId, string publisherName, string address, string email, string phone, string website, string contactPerson)
        {
            PublisherId = publisherId;
            PublisherName = publisherName;
            Address = address;
            Email = email;
            Phone = phone;
            Website = website;
            ContactPerson = contactPerson;
        }
    }
}
