﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Lebedeva_Juliya.Classes
{
    public class UserProfil
    {
        // Основная информация
        public int UserId { get; set; }
        public string Login { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string RoleName { get; set; }
        public bool IsActive { get; set; }

        // Персональные данные (документы)
        public string DocumentSeries { get; set; }
        public string DocumentNumber { get; set; }
        public DateTime? DocumentIssueDate { get; set; }
        public string DocumentIssuedBy { get; set; }

        // Информация о читателе (если role_id = 1)
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Patronymic { get; set; }
        public DateTime? BirthDate { get; set; }
        public string Address { get; set; }
        public DateTime? RegistrationDate { get; set; }

        // Информация о сотруднике (если role_id = 2)
        public string Position { get; set; }

        // Определение типа пользователя
        public bool IsReader => RoleName == "Читатель";
        public bool IsEmployee => RoleName == "Библиотекарь";
    }
}
